# Harbourline Hotel: Smart Room Booking System
React + Vite + Tailwind · Node + Express · MongoDB

## Setup
1. Install Node 18+ and MongoDB (local, or Atlas URI).
2. `cd server && cp .env.example .env` (set `MONGO_URI`, `ADMIN_KEY`) then `npm install && npm run seed && npm run dev` (API on :5000)
3. `cd client && npm install && npm run dev` (UI on http://localhost:5173, `/api` is proxied)
4. Admin tab: enter the `ADMIN_KEY`. Demo guest emails: asha@example.com, vikram@example.com

## REST API
| Method | Route | Purpose |
|---|---|---|
| GET | /api/rooms[?type=] | List rooms |
| GET | /api/rooms/search?checkIn&checkOut&guests&type&required&preferred&budget&freeCancel&wPrice… | Available rooms ranked with explanations |
| POST/PUT/DELETE | /api/rooms[/:id] | Admin room CRUD (`x-admin-key`) |
| GET | /api/bookings?email= | Guest bookings (admin key lists all) |
| POST | /api/bookings | Create booking (409 on overlap) |
| PUT | /api/bookings/:ref | Change dates (re-checks overlap) |
| DELETE | /api/bookings/:ref?email= | Cancel, policy-based refund |
| GET | /api/admin/stats, /api/events | Dashboard stats, real-time SSE |

## Decision engine (server/src/services/recommend.js)
Filters rooms by capacity, must-have facilities, budget and cancellation, then scores 0-100 on total stay cost (weekend +20%, 7+ nights -10%, 12% tax), facilities, distance, review-weighted rating and cancellation flexibility, using user-set priority weights. Every result lists reasons and trade-offs.

## Double-booking protection
Overlap rule `start < existingEnd && end > existingStart` (same-day turnover allowed), checked before insert, then re-verified after insert with rollback if an earlier booking exists. Optional hardening: MongoDB transactions on a replica set.
