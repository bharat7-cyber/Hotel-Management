// Demo data for a Nagpur hotel. Prices in INR per night (before 12% tax). distanceKm = distance to Sitabuldi / Zero Mile city centre.
const A = { wifi: 'WiFi', ac: 'AC', bf: 'Breakfast', pool: 'Pool', park: 'Parking', gym: 'Gym', bath: 'Bathtub', work: 'Work Desk', kit: 'Kitchenette',
  lake: 'Lake View', bal: 'Balcony', bar: 'Mini Bar', spa: 'Spa Access', tv: 'Smart TV' };
const R = (number, name, type, price, cap, am, pol, dist, rating, rc, description) => ({ number, name, type, pricePerNight: price, capacity: cap,
  amenities: am.map((k) => A[k]), cancellationPolicy: pol, distanceKm: dist, rating, reviewCount: rc, description });

export const rooms = [
  // Standard
  R('101', 'Sitabuldi Classic', 'Standard', 2400, 2, ['wifi', 'ac', 'tv'], 'strict', 0.6, 3.9, 142, 'Compact queen room a short walk from Sitabuldi Market and Zero Mile.'),
  R('102', 'Civil Lines Standard', 'Standard', 2800, 2, ['wifi', 'ac', 'tv', 'bf'], 'moderate', 1.4, 4.2, 211, 'Calm room overlooking the Civil Lines tree-lined avenue, breakfast included.'),
  R('103', 'Traveller Single', 'Standard', 2200, 1, ['wifi', 'ac', 'work'], 'flexible', 2.8, 4.0, 167, 'Single room with a proper work desk, ideal for solo business visits.'),
  R('104', 'Ramdaspeth Twin', 'Standard', 3000, 2, ['wifi', 'ac', 'tv', 'bf', 'park'], 'moderate', 2.2, 4.3, 189, 'Twin beds, free parking and quick access to Ramdaspeth restaurants.'),
  R('105', 'Dharampeth Comfort', 'Standard', 3200, 3, ['wifi', 'ac', 'tv', 'bf', 'bal'], 'flexible', 2.9, 4.4, 134, 'Bright room with a small balcony and an extra bed for a third guest.'),
  R('106', 'Airport Express Room', 'Standard', 2600, 2, ['wifi', 'ac', 'bf', 'park'], 'flexible', 8.5, 3.8, 96, 'Practical stay 10 minutes from Dr. Babasaheb Ambedkar Airport with 24-hour check-in.'),
  R('107', 'Itwari Budget Double', 'Standard', 2100, 2, ['wifi', 'ac'], 'strict', 3.4, 3.7, 78, 'Simple, clean and affordable near the Itwari railway side.'),
  R('108', 'Sadar Business Single', 'Standard', 2500, 1, ['wifi', 'ac', 'work', 'bf'], 'flexible', 1.9, 4.1, 93, 'Quiet single room in Sadar with a work desk and early breakfast for business travellers.'),
  // Deluxe
  R('201', 'Deluxe Futala View', 'Deluxe', 4800, 3, ['wifi', 'ac', 'bf', 'lake', 'bal', 'park'], 'flexible', 5.2, 4.6, 238, 'Spacious room with a balcony facing Futala Lake and the evening fountain show.'),
  R('202', 'Deluxe Orange City', 'Deluxe', 4200, 2, ['wifi', 'ac', 'bf', 'tv', 'bar'], 'moderate', 1.1, 4.4, 276, 'Elegant king room with an orange-and-teak palette, minibar and rain shower.'),
  R('203', 'Deluxe Business King', 'Deluxe', 4500, 2, ['wifi', 'ac', 'work', 'gym', 'park', 'bf'], 'moderate', 0.9, 4.5, 198, 'Ergonomic desk, fast WiFi and gym access; popular with corporate guests.'),
  R('204', 'Deluxe Pool Side', 'Deluxe', 5400, 3, ['wifi', 'ac', 'bf', 'pool', 'bal', 'tv'], 'flexible', 2.6, 4.7, 184, 'Steps from the swimming pool with a private sit-out.'),
  R('205', 'Deluxe Ambazari', 'Deluxe', 5100, 2, ['wifi', 'ac', 'bf', 'lake', 'bar', 'bath'], 'moderate', 4.6, 4.6, 152, 'Quiet room towards Ambazari Lake with a soaking tub.'),
  R('206', 'Deluxe Garden Terrace', 'Deluxe', 3900, 2, ['wifi', 'ac', 'bf', 'bal'], 'strict', 3.1, 4.1, 121, 'Ground-floor room opening to the landscaped garden terrace.'),
  R('207', 'Deluxe Wellness', 'Deluxe', 5800, 2, ['wifi', 'ac', 'bf', 'spa', 'gym', 'pool', 'bath'], 'moderate', 1.8, 4.8, 109, 'Includes daily spa access and a late check-out on request.'),
  // Suites
  R('301', 'Maharaja Suite', 'Suite', 9200, 4, ['wifi', 'ac', 'bf', 'pool', 'bath', 'bar', 'park', 'spa'], 'flexible', 1.5, 4.9, 118, 'Two-room suite with a separate lounge, soaking tub and butler service.'),
  R('302', 'Executive Suite', 'Suite', 7600, 3, ['wifi', 'ac', 'bf', 'gym', 'work', 'bath', 'bar'], 'strict', 0.5, 4.5, 163, 'Bedroom plus work lounge in the heart of Sitabuldi.'),
  R('303', 'Lake Panorama Suite', 'Suite', 8800, 3, ['wifi', 'ac', 'bf', 'lake', 'bal', 'bath', 'pool'], 'moderate', 5.0, 4.8, 92, 'Corner suite with panoramic views over Futala Lake.'),
  R('304', 'Junior Suite', 'Suite', 6400, 2, ['wifi', 'ac', 'bf', 'bar', 'work', 'tv'], 'moderate', 1.0, 4.4, 147, 'Open-plan junior suite with a sofa area and dining nook.'),
  R('305', 'Presidential Suite', 'Suite', 14500, 4, ['wifi', 'ac', 'bf', 'pool', 'bath', 'bar', 'spa', 'gym', 'park', 'bal'], 'flexible', 1.6, 4.9, 54, 'Top-floor flagship suite with private dining and a personal concierge.'),
  R('306', 'Heritage Suite', 'Suite', 7200, 3, ['wifi', 'ac', 'bf', 'bath', 'bal', 'park'], 'strict', 2.0, 4.3, 101, 'Warm wood interiors inspired by Vidarbha craftsmanship.'),
  // Family
  R('401', 'Family Haven', 'Family', 6200, 5, ['wifi', 'ac', 'bf', 'kit', 'park', 'pool'], 'flexible', 3.2, 4.5, 224, 'Two connecting bedrooms with a kitchenette and pool access.'),
  R('402', 'Family Budget', 'Family', 4800, 4, ['wifi', 'ac', 'kit', 'tv'], 'moderate', 4.4, 4.0, 133, 'Practical four-bed room, great for weekend trips.'),
  R('403', 'Grand Family Room', 'Family', 7400, 6, ['wifi', 'ac', 'bf', 'kit', 'park', 'pool', 'bal'], 'strict', 2.4, 4.6, 87, 'Our largest room, with two bathrooms and a sit-out.'),
  R('404', 'Family Wardha Road', 'Family', 5200, 4, ['wifi', 'ac', 'bf', 'park', 'tv'], 'flexible', 6.1, 4.2, 119, 'Quiet family stay near Wardha Road with ample parking.'),
  R('405', 'Family Garden', 'Family', 5600, 4, ['wifi', 'ac', 'bf', 'bal', 'kit', 'pool'], 'moderate', 2.7, 4.4, 146, 'Garden-facing room with a children’s play area nearby.'),
  R('406', 'Family Studio', 'Family', 5900, 5, ['wifi', 'ac', 'kit', 'park', 'bf', 'gym'], 'moderate', 3.6, 4.3, 102, 'Open-plan studio with sofa-bed and kitchenette.'),
  R('407', 'Family Orange Grove', 'Family', 6800, 6, ['wifi', 'ac', 'bf', 'kit', 'pool', 'park', 'bal', 'tv'], 'flexible', 3.9, 4.7, 76, 'Spacious three-bed family room with a balcony over the orange-tree garden and pool access.')
];

// [room no., check-in offset (days from today), check-out offset, guest, email, guests, phone, status]
const g = (room, a, b, name, email, guests, phone, status = 'confirmed') => ({ room, a, b, name, email, guests, phone, status });
export const bookings = [
  g('201', 1, 4, 'Aarav Deshmukh', 'aarav.deshmukh@example.com', 2, '+91 98230 11234'),   // overlaps default search
  g('203', 0, 3, 'Priya Kulkarni', 'priya.kulkarni@example.com', 2, '+91 98901 22345'),   // in-house
  g('301', 2, 6, 'Rohit Agrawal', 'rohit.agrawal@example.com', 3, '+91 99600 33456'),
  g('402', 1, 3, 'Sneha Joshi', 'sneha.joshi@example.com', 4, '+91 97650 44567'),
  g('105', 2, 5, 'Imran Sheikh', 'imran.sheikh@example.com', 2, '+91 98220 55678'),
  g('204', 5, 8, 'Kavita Wankhede', 'kavita.wankhede@example.com', 3, '+91 98812 66789'),
  g('204', 9, 12, 'Siddharth Bhoyar', 'siddharth.bhoyar@example.com', 2, '+91 90110 77890'),
  g('401', 4, 8, 'Meera Iyer', 'meera.iyer@example.com', 5, '+91 98500 88901'),
  g('305', 7, 10, 'Vikram Malhotra', 'vikram.malhotra@example.com', 2, '+91 98100 99012'),
  g('207', 3, 6, 'Ananya Pawar', 'ananya.pawar@example.com', 2, '+91 98343 10123'),
  g('104', 6, 9, 'Harshad Thakre', 'harshad.thakre@example.com', 2, '+91 93700 21234'),
  g('202', 10, 14, 'Nisha Gupta', 'nisha.gupta@example.com', 2, '+91 98600 32345'),
  g('303', 12, 15, 'Rajesh Nair', 'rajesh.nair@example.com', 3, '+91 94220 43456'),
  g('403', 8, 11, 'Deepa Rathod', 'deepa.rathod@example.com', 6, '+91 97300 54567'),
  g('102', 1, 3, 'Tanmay Chavan', 'tanmay.chavan@example.com', 2, '+91 99220 65678', 'cancelled'),
  g('302', 14, 17, 'Shruti Mehta', 'shruti.mehta@example.com', 2, '+91 98200 76789'),
  g('106', -1, 2, 'Farhan Qureshi', 'farhan.qureshi@example.com', 2, '+91 98221 87890'),     // in-house
  g('404', 3, 6, 'Pooja Bhagat', 'pooja.bhagat@example.com', 4, '+91 97640 98901')
];

export const coupons = [
  { code: 'WELCOME10', description: '10% off your first stay', type: 'percent', value: 10, minNights: 1, maxDiscount: 1500 },
  { code: 'MONSOON500', description: 'Flat ₹500 off stays of 2+ nights', type: 'flat', value: 500, minNights: 2 },
  { code: 'LONGSTAY15', description: '15% off stays of 5+ nights', type: 'percent', value: 15, minNights: 5, maxDiscount: 5000 }
];
export const tasks = [
  { kind: 'housekeeping', room: '203', title: 'Daily service and linen change', priority: 'medium', status: 'in_progress', assignee: 'Sunita' },
  { kind: 'housekeeping', room: '402', title: 'Deep clean before arrival', priority: 'high', status: 'open', assignee: 'Ramesh' },
  { kind: 'maintenance', room: '107', title: 'AC not cooling', priority: 'high', status: 'open', assignee: 'Prakash' },
  { kind: 'maintenance', room: '206', title: 'Replace bathroom tap', priority: 'low', status: 'done', assignee: 'Prakash' }
];
