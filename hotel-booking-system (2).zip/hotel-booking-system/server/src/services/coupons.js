import { Coupon } from '../models/Ops.js';
import { HttpError } from '../middleware/index.js';
/** Validates a coupon against a priced stay and applies it to pricing (adds couponDiscount, reduces total). Returns the code. */
export async function applyCoupon(code, pricing) {
  const c = await Coupon.findOne({ code: code.toUpperCase(), active: true });
  if (!c || (c.expiresAt && c.expiresAt < new Date())) throw new HttpError(422, 'Coupon is invalid or expired');
  if (pricing.nights < c.minNights) throw new HttpError(422, `${c.code} needs a stay of at least ${c.minNights} nights`);
  let off = c.type === 'percent' ? pricing.total * (c.value / 100) : c.value;
  if (c.maxDiscount) off = Math.min(off, c.maxDiscount);
  off = Math.round(Math.min(off, pricing.total) * 100) / 100;
  pricing.couponDiscount = off; pricing.total = Math.round((pricing.total - off) * 100) / 100;
  return c.code;
}
