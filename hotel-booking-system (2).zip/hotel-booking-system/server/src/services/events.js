const clients = new Set();
export const sseHandler = (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  res.write('retry: 3000\n\n'); clients.add(res);
  req.on('close', () => clients.delete(res));
};
export const broadcast = (type, data = {}) => clients.forEach((c) => c.write(`data: ${JSON.stringify({ type, ...data })}\n\n`));
