import { Notification } from '../models/Ops.js';
import { broadcast } from './events.js';
export async function notify(type, title, message) { await Notification.create({ type, title, message }); broadcast('notification'); }
