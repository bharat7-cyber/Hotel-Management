import { priceStay, freeCancelDays, policyText } from './availability.js';
const norm = (v, min, max, invert) => { const x = max === min ? 1 : (v - min) / (max - min); return Math.round((invert ? 1 - x : x) * 100); };
const clamp = (n) => Math.max(0, Math.min(100, n));
const inr = (n) => '₹' + Math.round(n).toLocaleString('en-IN');

/** Scores every available room 0-100 on value, comfort, location, rating and flexibility, then explains the result. */
export function recommend(rooms, { start, end, guests, requiredAmenities = [], niceToHave = [], budgetPerNight, freeCancelOnly, weights }) {
  const w = { price: 3, comfort: 2, location: 2, rating: 2, ...weights };
  const wSum = w.price + w.comfort + w.location + w.rating + 1;
  const lower = (a) => a.map((x) => x.toLowerCase());
  const excluded = { capacity: 0, amenities: 0, budget: 0, cancellation: 0 };
  const cands = [];
  for (const room of rooms) {
    const has = lower(room.amenities);
    if (room.capacity < guests) { excluded.capacity++; continue; }
    if (lower(requiredAmenities).some((a) => !has.includes(a))) { excluded.amenities++; continue; }
    if (freeCancelOnly && room.cancellationPolicy === 'strict') { excluded.cancellation++; continue; }
    const pricing = priceStay(room, start, end);
    if (budgetPerNight && pricing.total / pricing.nights > budgetPerNight) { excluded.budget++; continue; }
    cands.push({ room, pricing });
  }
  if (!cands.length) return { results: [], excluded, summary: null };
  const totals = cands.map((c) => c.pricing.total), dists = cands.map((c) => c.room.distanceKm);
  const [tMin, tMax, dMin, dMax] = [Math.min(...totals), Math.max(...totals), Math.min(...dists), Math.max(...dists)];
  const avg = totals.reduce((a, b) => a + b, 0) / totals.length;
  const results = cands.map(({ room, pricing }) => {
    const has = lower(room.amenities), nice = lower(niceToHave);
    const matched = nice.filter((a) => has.includes(a));
    const spare = room.capacity - guests;
    const comfort = clamp((nice.length ? (matched.length / nice.length) * 70 : 50) + Math.min(room.amenities.length, 10) * 2 - spare * 4 + 10);
    const value = norm(pricing.total, tMin, tMax, true);
    const location = norm(room.distanceKm, dMin, dMax, true);
    const rating = clamp(Math.round(((room.rating - 3) / 2) * 100 * Math.min(1, 0.6 + room.reviewCount / 250)));
    const flex = { flexible: 100, moderate: 60, strict: 20 }[room.cancellationPolicy];
    const breakdown = { value, comfort, location, rating, flexibility: flex };
    const score = Math.round((value * w.price + comfort * w.comfort + location * w.location + rating * w.rating + flex) / wSum);
    const reasons = [], tradeoffs = [];
    if (pricing.total <= tMin * 1.02) reasons.push(`Lowest total for ${pricing.nights} night${pricing.nights > 1 ? 's' : ''}: ${inr(pricing.total)} incl. tax`);
    else if (pricing.total < avg) reasons.push(`${inr(avg - pricing.total)} below the average of available rooms`);
    else tradeoffs.push(`${inr(pricing.total - tMin)} more than the cheapest option`);
    if (pricing.discount) reasons.push(`Long-stay discount saves ${inr(pricing.discount)}`);
    if (matched.length) reasons.push(`Has ${matched.length}/${nice.length} preferred facilities: ${matched.join(', ')}`);
    if (nice.length > matched.length) tradeoffs.push(`Missing: ${nice.filter((a) => !has.includes(a)).join(', ')}`);
    if (requiredAmenities.length) reasons.push('Includes all your must-have facilities');
    if (spare === 0) reasons.push(`Fits ${guests} guest${guests > 1 ? 's' : ''} exactly, no paying for unused space`);
    else if (spare >= 2) tradeoffs.push(`Sleeps ${room.capacity}, more space than you need`);
    if (room.distanceKm <= dMin + 0.3) reasons.push(`Closest to the centre (${room.distanceKm} km)`);
    else if (room.distanceKm > 4) tradeoffs.push(`${room.distanceKm} km from the centre`);
    if (room.rating >= 4.5) reasons.push(`Top-rated: ${room.rating}★ from ${room.reviewCount} reviews`);
    else if (room.rating < 4) tradeoffs.push(`Rated ${room.rating}★`);
    reasons.push(policyText(room.cancellationPolicy));
    if (room.cancellationPolicy === 'strict') tradeoffs.push('Strict cancellation policy');
    return { room, pricing, score, breakdown, reasons: reasons.slice(0, 5), tradeoffs: tradeoffs.slice(0, 3), freeCancelDays: freeCancelDays(room.cancellationPolicy) };
  }).sort((a, b) => b.score - a.score);
  results.forEach((r, i) => { r.rank = i + 1; r.badge = i === 0 ? 'Best overall' : r.pricing.total === tMin ? 'Best price' : null; });
  return { results, excluded, summary: `Best match: ${results[0].room.name} (${results[0].score}/100). ${results[0].reasons[0]}.` };
}
