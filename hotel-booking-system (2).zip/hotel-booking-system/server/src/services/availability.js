import Room from '../models/Room.js';
import Booking from '../models/Booking.js';
export const DAY = 864e5;
export const parseDate = (s) => new Date(`${s}T00:00:00.000Z`);
export const nightsBetween = (a, b) => Math.round((b - a) / DAY);

// Stays overlap when start < otherEnd AND end > otherStart (check-out day is reusable).
export const overlapQuery = (start, end) => ({ status: 'confirmed', checkIn: { $lt: end }, checkOut: { $gt: start } });

export async function isRoomFree(roomId, start, end, excludeId) {
  const q = { room: roomId, ...overlapQuery(start, end) };
  if (excludeId) q._id = { $ne: excludeId };
  return !(await Booking.exists(q));
}
export async function availableRooms(filter, start, end) {
  const booked = await Booking.distinct('room', overlapQuery(start, end));
  return Room.find({ active: true, status: { $ne: 'Maintenance' }, _id: { $nin: booked }, ...filter }).lean();
}
// Dynamic pricing: Fri/Sat +20%, 7+ nights -10%, 12% tax.
export function priceStay(room, start, end) {
  const nights = nightsBetween(start, end);
  let subtotal = 0;
  for (let i = 0; i < nights; i++) {
    const d = new Date(start.getTime() + i * DAY).getUTCDay();
    subtotal += room.pricePerNight * (d === 5 || d === 6 ? 1.2 : 1);
  }
  const discount = nights >= 7 ? subtotal * 0.1 : 0;
  const tax = (subtotal - discount) * 0.12;
  const r = (n) => Math.round(n * 100) / 100;
  return { nights, subtotal: r(subtotal), discount: r(discount), tax: r(tax), total: r(subtotal - discount + tax) };
}
const WINDOW = { flexible: [1, 0.5], moderate: [3, 0.5], strict: [7, 0] }; // [free-cancel days, refund share after window]
export const policyText = (p) => ({
  flexible: 'Free cancellation until 1 day before check-in', moderate: 'Free cancellation until 3 days before check-in',
  strict: 'Free cancellation until 7 days before check-in, no refund after' })[p];
export function refundFor(booking, now = new Date()) {
  const [days, share] = WINDOW[booking.cancellationPolicy] || WINDOW.moderate;
  if (now >= booking.checkIn) return 0;
  const daysLeft = (booking.checkIn - now) / DAY;
  return Math.round(booking.pricing.total * (daysLeft >= days ? 1 : share) * 100) / 100;
}
export const freeCancelDays = (p) => WINDOW[p][0];
