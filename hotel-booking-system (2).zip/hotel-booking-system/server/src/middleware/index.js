import { ZodError } from 'zod';
export class HttpError extends Error { constructor(status, message, details) { super(message); this.status = status; this.details = details; } }
export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
export const isAdmin = (req) => !!process.env.ADMIN_KEY && req.get('x-admin-key') === process.env.ADMIN_KEY;
export const adminOnly = (req, _res, next) => (isAdmin(req) ? next() : next(new HttpError(401, 'Admin key missing or invalid')));
export const notFound = (_req, _res, next) => next(new HttpError(404, 'Route not found'));
export const errorHandler = (err, _req, res, _next) => {
  if (err instanceof ZodError) return res.status(400).json({ error: 'Validation failed', details: err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })) });
  if (err.name === 'CastError') return res.status(400).json({ error: 'Invalid id' });
  if (err.code === 11000) return res.status(409).json({ error: 'Duplicate value', details: err.keyValue });
  if (!err.status) console.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'Internal server error', details: err.details });
};
