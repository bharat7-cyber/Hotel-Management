import { z } from 'zod';
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD').refine((s) => !isNaN(Date.parse(s)), 'Invalid date');
const today = () => new Date().toISOString().slice(0, 10);
export const stay = z.object({ checkIn: date, checkOut: date }).passthrough()
  .refine((d) => d.checkIn >= today(), { path: ['checkIn'], message: 'Check-in cannot be in the past' })
  .refine((d) => d.checkOut > d.checkIn, { path: ['checkOut'], message: 'Check-out must be after check-in' })
const roomBase = z.object({
  number: z.string().trim().min(1).max(10), name: z.string().trim().min(2).max(60),
  type: z.enum(['Standard', 'Deluxe', 'Suite', 'Family']), pricePerNight: z.number().positive().max(1e6),
  capacity: z.number().int().min(1).max(10), amenities: z.array(z.string().trim().min(1).max(30)).max(20).default([]),
  cancellationPolicy: z.enum(['flexible', 'moderate', 'strict']).default('moderate'),
  distanceKm: z.number().min(0).max(100).default(1), rating: z.number().min(0).max(5).default(4),
  reviewCount: z.number().int().min(0).default(0), description: z.string().max(400).default(''), active: z.boolean().default(true)
});
export const roomCreate = roomBase; export const roomUpdate = roomBase.partial();
const csv = z.string().optional().transform((s) => (s ? s.split(',').map((x) => x.trim()).filter(Boolean) : []));
export const searchQuery = z.object({
  checkIn: date, checkOut: date, guests: z.coerce.number().int().min(1).max(10).default(1),
  type: z.enum(['Standard', 'Deluxe', 'Suite', 'Family']).optional(), required: csv, preferred: csv,
  budget: z.coerce.number().positive().optional(), freeCancel: z.enum(['true', 'false']).optional(),
  wPrice: z.coerce.number().min(0).max(5).default(3), wComfort: z.coerce.number().min(0).max(5).default(2),
  wLocation: z.coerce.number().min(0).max(5).default(2), wRating: z.coerce.number().min(0).max(5).default(2)
});
export const bookingCreate = z.object({
  roomId: z.string().length(24, 'Invalid room id'), guests: z.number().int().min(1).max(10),
  guest: z.object({ name: z.string().trim().min(2).max(80), email: z.string().trim().toLowerCase().email().max(120),
    phone: z.string().trim().regex(/^[+\d][\d\s-]{6,14}$/, 'Invalid phone').optional().or(z.literal('')) }),
  checkIn: date, checkOut: date,
  couponCode: z.string().trim().toUpperCase().max(20).optional().or(z.literal('')), paymentMethod: z.enum(['card', 'upi', 'pay_at_hotel']).default('pay_at_hotel')
});
export const bookingUpdate = z.object({ email: z.string().trim().toLowerCase().email(), checkIn: date, checkOut: date, guests: z.number().int().min(1).max(10).optional() });
