import { Router } from 'express';
import Room from '../models/Room.js';
import Booking from '../models/Booking.js';
import { wrap, adminOnly } from '../middleware/index.js';
const r = Router(); r.use(adminOnly);
r.get('/stats', wrap(async (_req, res) => {
  const DAY = 864e5, d0 = new Date(new Date().toISOString().slice(0, 10) + 'T00:00:00.000Z');
  const [rooms, all] = await Promise.all([Room.find({ active: true }).lean(), Booking.find({ status: 'confirmed' }).lean()]);
  const type = Object.fromEntries(rooms.map((r) => [String(r._id), r.type]));
  const occ = (d) => new Set(all.filter((b) => b.checkIn <= d && b.checkOut > d).map((b) => String(b.room))).size;
  const byType = {}; all.forEach((b) => { const t = type[String(b.room)] || 'Other'; (byType[t] ||= { _id: t, revenue: 0, bookings: 0 }); byType[t].revenue += b.pricing.total; byType[t].bookings++; });
  const trend = Array.from({ length: 14 }, (_, i) => { const d = new Date(d0.getTime() + (i - 3) * DAY); const rev = all.filter((b) => b.checkIn.getTime() === d.getTime()).reduce((a, b) => a + b.pricing.total, 0);
    return { date: d.toISOString().slice(5, 10), occupancyPct: rooms.length ? Math.round((occ(d) / rooms.length) * 100) : 0, revenue: Math.round(rev) }; });
  const statusCounts = {}; rooms.forEach((r) => (statusCounts[r.status || 'Available'] = (statusCounts[r.status || 'Available'] || 0) + 1));
  res.json({ rooms: rooms.length, occupiedToday: occ(d0), occupancyPct: rooms.length ? Math.round((occ(d0) / rooms.length) * 100) : 0, upcomingBookings: all.filter((b) => b.checkOut > d0).length,
    revenue: all.reduce((a, b) => a + b.pricing.total, 0), byType: Object.values(byType), trend, statusCounts, cancelled: await Booking.countDocuments({ status: 'cancelled' }) });
}));
export default r;
