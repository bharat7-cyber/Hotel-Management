import { Router } from 'express';
import Room from '../models/Room.js';
import Booking from '../models/Booking.js';
import { Coupon, Task, Notification } from '../models/Ops.js';
import { wrap, adminOnly, HttpError } from '../middleware/index.js';
import { isRoomFree, priceStay, parseDate, DAY } from '../services/availability.js';
import { applyCoupon } from '../services/coupons.js';
import { notify } from '../services/notify.js';
import { broadcast } from '../services/events.js';
import { guardedInsert } from './bookings.js';
import { bookingCreate } from '../validators.js';
import crypto from 'crypto';
const r = Router(); const day = (d = new Date()) => d.toISOString().slice(0, 10);

// Public: validate a coupon and preview the discount
r.post('/coupons/validate', wrap(async (req, res) => {
  const { code, total, nights } = req.body || {}; const p = { total: Number(total), nights: Number(nights) };
  if (!code || !(p.total > 0) || !(p.nights > 0)) throw new HttpError(400, 'code, total and nights are required');
  await applyCoupon(String(code), p); res.json({ code: String(code).toUpperCase(), couponDiscount: p.couponDiscount, total: p.total });
}));
// Public: invoice for a booking (needs email)
r.get('/invoice/:ref', wrap(async (req, res) => {
  const b = await Booking.findOne({ ref: req.params.ref, 'guest.email': String(req.query.email || '').toLowerCase() }).populate('room', 'name number type').lean();
  if (!b) throw new HttpError(404, 'Booking not found'); res.json({ invoiceNo: 'INV-' + b.ref.slice(3), issuedAt: new Date(), hotel: { name: 'Harbourline Hotel', city: 'Nagpur', gstin: '27ABCDE1234F1Z5' }, booking: b });
}));
r.use(adminOnly);
r.get('/coupons', wrap(async (_q, s) => s.json(await Coupon.find().lean())));
r.post('/coupons', wrap(async (q, s) => s.status(201).json(await Coupon.create(q.body))));
r.put('/rooms/:id/status', wrap(async (req, res) => {
  const room = await Room.findByIdAndUpdate(req.params.id, { status: String(req.body.status) }, { new: true, runValidators: true });
  if (!room) throw new HttpError(404, 'Room not found');
  if (room.status === 'Maintenance') { await Task.create({ kind: 'maintenance', room: room._id, title: 'Room taken out of service', priority: 'high' }); }
  broadcast('availability'); res.json(room);
}));
const load = async (ref) => { const b = await Booking.findOne({ ref }); if (!b) throw new HttpError(404, 'Booking not found'); if (b.status !== 'confirmed') throw new HttpError(422, 'Booking is not active'); return b; };
r.post('/bookings/:ref/check-in', wrap(async (req, res) => {
  const b = await load(req.params.ref); if (b.checkedInAt) throw new HttpError(409, 'Already checked in');
  if (day(b.checkIn) > day()) throw new HttpError(422, 'Check-in date is in the future');
  const room = await Room.findById(b.room); if (['Maintenance', 'Cleaning'].includes(room.status)) throw new HttpError(422, `Room is ${room.status}`);
  b.checkedInAt = new Date(); await b.save(); room.status = 'Occupied'; await room.save(); broadcast('availability'); res.json(b);
}));
r.post('/bookings/:ref/check-out', wrap(async (req, res) => {
  const b = await load(req.params.ref); if (!b.checkedInAt) throw new HttpError(422, 'Guest has not checked in');
  b.checkedOutAt = new Date(); if (b.payment.status !== 'paid') b.payment.status = 'paid'; await b.save();
  const room = await Room.findByIdAndUpdate(b.room, { status: 'Cleaning' }, { new: true });
  await Task.create({ kind: 'housekeeping', room: room._id, title: `Turnover clean after ${b.ref}`, priority: 'high' });
  await notify('checkout', `Room ${room.number} checked out`, 'Housekeeping task created.'); broadcast('availability'); res.json(b);
}));
r.put('/bookings/:ref/extend', wrap(async (req, res) => {
  const b = await load(req.params.ref); const co = String(req.body.checkOut || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(co) || parseDate(co) <= b.checkOut) throw new HttpError(400, 'New check-out must be after the current one');
  const end = parseDate(co); if (!(await isRoomFree(b.room, b.checkIn, end, b._id))) throw new HttpError(409, 'Room is booked by someone else on those nights');
  const room = await Room.findById(b.room); b.checkOut = end; b.pricing = { ...priceStay(room, b.checkIn, end), couponDiscount: 0 }; await b.save(); broadcast('availability'); res.json(b);
}));
r.put('/bookings/:ref/change-room', wrap(async (req, res) => {
  const b = await load(req.params.ref); const room = await Room.findById(req.body.roomId);
  if (!room || !room.active || room.status === 'Maintenance') throw new HttpError(404, 'Room not available');
  if (room.capacity < b.guests) throw new HttpError(422, `Room sleeps max ${room.capacity}`);
  if (!(await isRoomFree(room._id, b.checkIn, b.checkOut, b._id))) throw new HttpError(409, 'Room is not free for this stay');
  const old = b.room; b.room = room._id; b.cancellationPolicy = room.cancellationPolicy; b.pricing = { ...priceStay(room, b.checkIn, b.checkOut), couponDiscount: 0 };
  await b.save(); if (b.checkedInAt) { await Room.findByIdAndUpdate(old, { status: 'Cleaning' }); await Task.create({ kind: 'housekeeping', room: old, title: 'Clean vacated room', priority: 'high' }); room.status = 'Occupied'; await room.save(); }
  broadcast('availability'); res.json(b);
}));
r.post('/walk-in', wrap(async (req, res) => {
  const { nights = 1, roomId, ...rest } = req.body; const n = Math.max(1, Math.min(60, Number(nights) || 1));
  const checkIn = day(), checkOut = day(new Date(Date.now() + n * DAY));
  const d = bookingCreate.parse({ roomId, ...rest, checkIn, checkOut, paymentMethod: rest.paymentMethod || 'pay_at_hotel' });
  const room = await Room.findById(d.roomId); if (!room || !room.active || ['Maintenance', 'Cleaning'].includes(room.status)) throw new HttpError(422, 'Room is not ready');
  if (d.guests > room.capacity) throw new HttpError(422, `Room sleeps max ${room.capacity}`);
  const start = parseDate(checkIn), end = parseDate(checkOut); if (!(await isRoomFree(room._id, start, end))) throw new HttpError(409, 'Room is booked for these dates');
  const paid = d.paymentMethod !== 'pay_at_hotel';
  const b = await guardedInsert({ ref: 'HB-' + crypto.randomBytes(4).toString('hex').toUpperCase(), room: room._id, guest: d.guest, guests: d.guests, checkIn: start, checkOut: end,
    pricing: priceStay(room, start, end), cancellationPolicy: room.cancellationPolicy, source: 'walk-in', checkedInAt: new Date(), payment: { method: d.paymentMethod, status: paid ? 'paid' : 'pending' } });
  room.status = 'Occupied'; await room.save(); await notify('walk-in', `Walk-in ${b.ref}`, `${d.guest.name} checked into room ${room.number}.`); broadcast('availability'); res.status(201).json(b);
}));
r.get('/tasks', wrap(async (req, res) => res.json(await Task.find(req.query.kind ? { kind: req.query.kind } : {}).populate('room', 'number name').sort('-createdAt').limit(100).lean())));
r.post('/tasks', wrap(async (req, res) => {
  const t = await Task.create({ kind: req.body.kind, room: req.body.room, title: req.body.title, priority: req.body.priority, assignee: req.body.assignee });
  if (t.kind === 'maintenance' && t.room) await Room.findByIdAndUpdate(t.room, { status: 'Maintenance' });
  await notify(t.kind, `New ${t.kind} task`, t.title); broadcast('availability'); res.status(201).json(t);
}));
r.put('/tasks/:id', wrap(async (req, res) => {
  const t = await Task.findById(req.params.id); if (!t) throw new HttpError(404, 'Task not found');
  if (req.body.status) { t.status = req.body.status; t.completedAt = t.status === 'done' ? new Date() : undefined; }
  if (req.body.assignee !== undefined) t.assignee = req.body.assignee; await t.save();
  if (t.status === 'done' && t.room) { const open = await Task.exists({ room: t.room, status: { $ne: 'done' }, _id: { $ne: t._id } }); if (!open) await Room.findByIdAndUpdate(t.room, { status: 'Available' }); }
  broadcast('availability'); res.json(t);
}));
r.get('/notifications', wrap(async (_q, s) => s.json(await Notification.find().sort('-createdAt').limit(30).lean())));
r.put('/notifications/read', wrap(async (_q, s) => { await Notification.updateMany({}, { read: true }); s.json({ ok: true }); }));
export default r;
