import { Router } from 'express';
import crypto from 'crypto';
import Room from '../models/Room.js';
import Booking from '../models/Booking.js';
import { wrap, isAdmin, HttpError } from '../middleware/index.js';
import { bookingCreate, bookingUpdate, stay } from '../validators.js';
import { parseDate, isRoomFree, priceStay, refundFor, overlapQuery } from '../services/availability.js';
import { applyCoupon } from '../services/coupons.js';
import { notify } from '../services/notify.js';
import { broadcast } from '../services/events.js';
const r = Router();
const newRef = () => 'HB-' + crypto.randomBytes(4).toString('hex').toUpperCase();

// Insert, then verify no earlier-created overlapping booking exists; roll back if we lost the race.
// Prevents double booking under concurrency without needing a replica-set transaction.
export async function guardedInsert(doc) {
  const b = await Booking.create(doc);
  const clash = await Booking.exists({ _id: { $ne: b._id }, room: doc.room, ...overlapQuery(doc.checkIn, doc.checkOut), createdAt: { $lte: b.createdAt } });
  if (clash) { await Booking.deleteOne({ _id: b._id }); throw new HttpError(409, 'Room was just booked by someone else for these dates'); }
  return b;
}
r.get('/', wrap(async (req, res) => {
  if (req.query.email) {
    const list = await Booking.find({ 'guest.email': String(req.query.email).trim().toLowerCase() }).populate('room', 'name number type').sort('-createdAt').lean();
    return res.json(list.map((b) => ({ ...b, refundIfCancelled: b.status === 'confirmed' ? refundFor(b) : 0 })));
  }
  if (!isAdmin(req)) throw new HttpError(401, 'Provide ?email= or an admin key');
  res.json(await Booking.find().populate('room', 'name number type').sort('-createdAt').limit(200).lean());
}));
r.post('/', wrap(async (req, res) => {
  const d = bookingCreate.parse(req.body); stay.parse(d);
  const room = await Room.findById(d.roomId);
  if (!room || !room.active) throw new HttpError(404, 'Room not available');
  if (d.guests > room.capacity) throw new HttpError(422, `Room sleeps max ${room.capacity} guests`);
  const start = parseDate(d.checkIn), end = parseDate(d.checkOut);
  if (!(await isRoomFree(room._id, start, end))) throw new HttpError(409, 'Room is already booked for these dates');
  const pricing = priceStay(room, start, end);
  const couponCode = d.couponCode ? await applyCoupon(d.couponCode, pricing) : undefined;   // mutates pricing.total
  const paid = d.paymentMethod !== 'pay_at_hotel';
  const payment = { method: d.paymentMethod, status: paid ? 'paid' : 'pending', txnId: paid ? 'TXN' + crypto.randomBytes(5).toString('hex').toUpperCase() : undefined };
  const b = await guardedInsert({ ref: newRef(), room: room._id, guest: d.guest, guests: d.guests, checkIn: start, checkOut: end,
    pricing, cancellationPolicy: room.cancellationPolicy, couponCode, payment });
  await notify('booking', `New booking ${b.ref}`, `${d.guest.name} booked ${room.name} (${d.checkIn} to ${d.checkOut}).`);
  broadcast('availability', { roomId: String(room._id) });
  res.status(201).json(b);
}));
r.put('/:ref', wrap(async (req, res) => {
  const d = bookingUpdate.parse(req.body); stay.parse(d);
  const b = await Booking.findOne({ ref: req.params.ref, 'guest.email': d.email });
  if (!b) throw new HttpError(404, 'Booking not found for this email');
  if (b.status !== 'confirmed') throw new HttpError(422, 'Cancelled bookings cannot be changed');
  const room = await Room.findById(b.room);
  const guests = d.guests ?? b.guests; if (guests > room.capacity) throw new HttpError(422, `Room sleeps max ${room.capacity}`);
  const start = parseDate(d.checkIn), end = parseDate(d.checkOut);
  if (!(await isRoomFree(b.room, start, end, b._id))) throw new HttpError(409, 'Room is not free for the new dates');
  Object.assign(b, { checkIn: start, checkOut: end, guests, pricing: priceStay(room, start, end) });
  await b.save(); broadcast('availability', { roomId: String(b.room) }); res.json(b);
}));
r.delete('/:ref', wrap(async (req, res) => {
  const email = String(req.query.email || '').trim().toLowerCase();
  const b = await Booking.findOne({ ref: req.params.ref, ...(isAdmin(req) ? {} : { 'guest.email': email }) });
  if (!b) throw new HttpError(404, 'Booking not found');
  if (b.status === 'cancelled') throw new HttpError(409, 'Already cancelled');
  if (b.checkIn <= new Date()) throw new HttpError(422, 'Stay has already started');
  b.refundAmount = refundFor(b); b.status = 'cancelled'; b.cancelledAt = new Date(); await b.save();
  await notify('cancellation', `Booking ${b.ref} cancelled`, `Refund ${b.refundAmount}.`);
  broadcast('availability', { roomId: String(b.room) });
  res.json({ message: 'Booking cancelled', refundAmount: b.refundAmount, booking: b });
}));
export default r;
