import { Router } from 'express';
import Room from '../models/Room.js';
import Booking from '../models/Booking.js';
import { wrap, adminOnly, HttpError } from '../middleware/index.js';
import { roomCreate, roomUpdate, stay, searchQuery } from '../validators.js';
import { parseDate, availableRooms } from '../services/availability.js';
import { recommend } from '../services/recommend.js';
import { broadcast } from '../services/events.js';
const r = Router();

r.get('/', wrap(async (req, res) => {
  const f = {}; if (req.query.type) f.type = String(req.query.type);
  if (req.query.all !== 'true') f.active = true;
  res.json(await Room.find(f).sort('number').lean());
}));
r.get('/search', wrap(async (req, res) => {
  const q = searchQuery.parse(req.query); stay.parse(q);
  const start = parseDate(q.checkIn), end = parseDate(q.checkOut);
  const rooms = await availableRooms(q.type ? { type: q.type } : {}, start, end);
  const out = recommend(rooms, { start, end, guests: q.guests, requiredAmenities: q.required, niceToHave: q.preferred,
    budgetPerNight: q.budget, freeCancelOnly: q.freeCancel === 'true',
    weights: { price: q.wPrice, comfort: q.wComfort, location: q.wLocation, rating: q.wRating } });
  res.json({ ...out, availableCount: rooms.length });
}));
r.get('/:id', wrap(async (req, res) => {
  const room = await Room.findById(req.params.id).lean(); if (!room) throw new HttpError(404, 'Room not found'); res.json(room);
}));
r.post('/', adminOnly, wrap(async (req, res) => { const room = await Room.create(roomCreate.parse(req.body)); broadcast('rooms'); res.status(201).json(room); }));
r.put('/:id', adminOnly, wrap(async (req, res) => {
  const room = await Room.findByIdAndUpdate(req.params.id, roomUpdate.parse(req.body), { new: true, runValidators: true });
  if (!room) throw new HttpError(404, 'Room not found'); broadcast('rooms'); res.json(room);
}));
r.delete('/:id', adminOnly, wrap(async (req, res) => {
  const future = await Booking.exists({ room: req.params.id, status: 'confirmed', checkOut: { $gt: new Date() } });
  if (future) throw new HttpError(409, 'Room has upcoming bookings. Cancel them first or deactivate the room.');
  const room = await Room.findByIdAndDelete(req.params.id); if (!room) throw new HttpError(404, 'Room not found');
  broadcast('rooms'); res.json({ message: 'Room deleted' });
}));
export default r;
