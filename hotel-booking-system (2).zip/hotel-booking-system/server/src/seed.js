import 'dotenv/config';
import mongoose from 'mongoose';
import Room from './models/Room.js';
import Booking from './models/Booking.js';
import { priceStay, DAY } from './services/availability.js';
import { rooms, bookings, coupons, tasks } from './demoData.js';
import { Coupon, Task, Notification } from './models/Ops.js';

await mongoose.connect(process.env.MONGO_URI);
await Room.deleteMany({}); await Booking.deleteMany({}); await Coupon.deleteMany({}); await Task.deleteMany({}); await Notification.deleteMany({});
const docs = await Room.insertMany(rooms);
const byNo = Object.fromEntries(docs.map((r) => [r.number, r]));
const today = new Date(new Date().toISOString().slice(0, 10) + 'T00:00:00.000Z').getTime();
const list = bookings.map((b, i) => {
  const room = byNo[b.room], checkIn = new Date(today + b.a * DAY), checkOut = new Date(today + b.b * DAY);
  const pricing = priceStay(room, checkIn, checkOut), cancelled = b.status === 'cancelled';
  return { ref: 'HB-DEMO' + String(i + 1).padStart(2, '0'), room: room._id, guest: { name: b.name, email: b.email, phone: b.phone }, guests: b.guests,
    checkIn, checkOut, pricing, cancellationPolicy: room.cancellationPolicy, status: b.status,
    ...(cancelled ? { refundAmount: pricing.total, cancelledAt: new Date() } : {}) };
});
await Booking.insertMany(list);
await Coupon.insertMany(coupons);
await Task.insertMany(tasks.map((t) => ({ ...t, room: byNo[t.room]._id })));
await Room.updateOne({ number: '203' }, { status: 'Occupied' }); await Room.updateOne({ number: '106' }, { status: 'Occupied' });
await Room.updateOne({ number: '402' }, { status: 'Cleaning' }); await Room.updateOne({ number: '107' }, { status: 'Maintenance' });
await Notification.insertMany([{ type: 'booking', title: 'New booking HB-DEMO01', message: 'Aarav Deshmukh booked Deluxe Futala View.' }, { type: 'maintenance', title: 'New maintenance task', message: 'AC not cooling in room 107.' }]);
console.log(`Seeded ${docs.length} rooms and ${list.length} bookings (demo guest e.g. aarav.deshmukh@example.com)`);
await mongoose.disconnect();
