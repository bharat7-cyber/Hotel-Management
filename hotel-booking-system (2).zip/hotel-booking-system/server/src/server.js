import 'dotenv/config';
import app from './app.js';
import connectDB from './config/db.js';
try { await connectDB(); } catch (e) { console.error('\nCould not connect to MongoDB at', process.env.MONGO_URI, '\nStart MongoDB (or fix MONGO_URI in server/.env) and run again.\n'); process.exit(1); }
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`API on http://localhost:${port}`));
