import mongoose from 'mongoose';
const bookingSchema = new mongoose.Schema({
  ref: { type: String, unique: true, index: true },
  room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true, index: true },
  guest: { name: { type: String, required: true }, email: { type: String, required: true, lowercase: true, index: true }, phone: String },
  guests: { type: Number, required: true, min: 1 },
  checkIn: { type: Date, required: true },
  checkOut: { type: Date, required: true },
  pricing: { nights: Number, subtotal: Number, discount: Number, tax: Number, couponDiscount: { type: Number, default: 0 }, total: Number },
  couponCode: String, source: { type: String, enum: ['online', 'walk-in'], default: 'online' },
  payment: { method: { type: String, default: 'pay_at_hotel' }, status: { type: String, default: 'pending' }, txnId: String },
  checkedInAt: Date, checkedOutAt: Date,
  cancellationPolicy: String,
  status: { type: String, enum: ['confirmed', 'cancelled'], default: 'confirmed', index: true },
  refundAmount: { type: Number, default: 0 },
  cancelledAt: Date
}, { timestamps: true });
bookingSchema.index({ room: 1, status: 1, checkIn: 1, checkOut: 1 });
export default mongoose.model('Booking', bookingSchema);
