import mongoose from 'mongoose';
const roomSchema = new mongoose.Schema({
  number: { type: String, required: true, unique: true, trim: true },
  name: { type: String, required: true, trim: true },
  type: { type: String, enum: ['Standard', 'Deluxe', 'Suite', 'Family'], required: true, index: true },
  pricePerNight: { type: Number, required: true, min: 1 },
  capacity: { type: Number, required: true, min: 1, max: 10 },
  amenities: [{ type: String, trim: true }],
  cancellationPolicy: { type: String, enum: ['flexible', 'moderate', 'strict'], default: 'moderate' },
  distanceKm: { type: Number, default: 1, min: 0 },
  rating: { type: Number, default: 4, min: 0, max: 5 },
  reviewCount: { type: Number, default: 0 },
  description: { type: String, default: '' },
  active: { type: Boolean, default: true },
  status: { type: String, enum: ['Available', 'Reserved', 'Occupied', 'Cleaning', 'Maintenance'], default: 'Available', index: true }
}, { timestamps: true });
export default mongoose.model('Room', roomSchema);
