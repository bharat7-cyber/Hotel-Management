import mongoose from 'mongoose';
export const Coupon = mongoose.model('Coupon', new mongoose.Schema({
  code: { type: String, unique: true, uppercase: true }, description: String, type: { type: String, enum: ['percent', 'flat'] }, value: Number,
  minNights: { type: Number, default: 1 }, maxDiscount: Number, expiresAt: Date, active: { type: Boolean, default: true } }));
export const Task = mongoose.model('Task', new mongoose.Schema({
  kind: { type: String, enum: ['housekeeping', 'maintenance'], index: true }, room: { type: mongoose.Schema.Types.ObjectId, ref: 'Room' },
  title: { type: String, required: true }, priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
  status: { type: String, enum: ['open', 'in_progress', 'done'], default: 'open' }, assignee: String, completedAt: Date }, { timestamps: true }));
export const Notification = mongoose.model('Notification', new mongoose.Schema({ type: String, title: String, message: String, read: { type: Boolean, default: false } }, { timestamps: true }));
