import { useState } from 'react';
import Search from './components/Search.jsx';
import MyBookings from './components/MyBookings.jsx';
import Admin from './components/Admin.jsx';
const tabs = [['find', 'Rooms & Suites'], ['mine', 'My Bookings'], ['admin', 'Admin']];
export default function App() {
  const [tab, setTab] = useState('find');
  return (<div className="min-h-screen">
    <header className="sticky top-0 z-20 border-b border-brass/20 bg-ink/95 backdrop-blur"><div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-3">
      <h1 className="text-2xl font-semibold tracking-wide text-white sm:text-3xl">Harbourline <span className="text-brass">Hotel</span></h1>
      <nav className="flex gap-1" aria-label="Main">{tabs.map(([k, l]) => (
        <button key={k} onClick={() => setTab(k)} aria-current={tab === k} className={`rounded-full px-3 py-1.5 text-sm transition sm:px-4 ${tab === k ? 'bg-brass text-ink' : 'text-white/75 hover:text-brass'}`}>{l}</button>))}</nav>
    </div></header>
    <main className="mx-auto max-w-6xl px-4 py-6">{tab === 'find' && <Search />}{tab === 'mine' && <MyBookings />}{tab === 'admin' && <Admin />}</main>
    <footer className="mt-10 bg-ink py-8 text-center text-sm text-white/60"><p className="font-display text-xl text-brass">Harbourline Hotel</p><p>Seafront · 24-hour concierge · Check-in from 2 pm</p></footer>
  </div>);
}
