import { useState, useEffect, useRef } from 'react';
import { api, money, errText, subscribe } from '../api.js';
import BookModal from './BookModal.jsx';
const U = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1600&q=70`;
const HERO = U('photo-1566073771259-6a8506099945');
const IMG = { Standard: U('photo-1631049307264-da0ec9d70304'), Deluxe: U('photo-1590490360182-c33d57733427'), Suite: U('photo-1582719478250-c89cae4dc85b'), Family: U('photo-1618773928121-c32242e63f39') };
const Photo = ({ src, className = '', children }) => (<div className={`relative overflow-hidden bg-gradient-to-br from-ink via-[#2a2216] to-tide ${className}`}>
  <img src={src} alt="" loading="lazy" onError={(e) => (e.currentTarget.style.display = 'none')} className="absolute inset-0 h-full w-full object-cover" />{children}</div>);
const AMEN = ['WiFi', 'AC', 'Breakfast', 'Pool', 'Parking', 'Gym', 'Sea View', 'Bathtub', 'Work Desk', 'Kitchenette'];
const iso = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
const PRIOS = [['wPrice', 'Low total cost'], ['wComfort', 'Facilities'], ['wLocation', 'Close to centre'], ['wRating', 'Guest ratings']];
const Bar = ({ label, v }) => (<div className="flex items-center gap-2 text-[11px]"><span className="w-20 text-white/60">{label}</span>
  <div className="h-1.5 flex-1 rounded bg-white/15"><div className="h-1.5 rounded bg-brass" style={{ width: v + '%' }} /></div><span className="w-6 text-right">{v}</span></div>);
export default function Search() {
  const [f, setF] = useState({ checkIn: iso(1), checkOut: iso(3), guests: 2, type: '', budget: 10000, freeCancel: false, wPrice: 3, wComfort: 2, wLocation: 2, wRating: 2 });
  const [must, setMust] = useState([]), [nice, setNice] = useState([]);
  const [res, setRes] = useState(null), [err, setErr] = useState(''), [loading, setLoading] = useState(false), [pick, setPick] = useState(null), [stale, setStale] = useState(false), [done, setDone] = useState(null);
  const last = useRef(null);
  const toggle = (list, set, a) => set(list.includes(a) ? list.filter((x) => x !== a) : [...list, a]);
  async function run(e) {
    e?.preventDefault(); setErr(''); setLoading(true); setStale(false);
    const p = new URLSearchParams({ checkIn: f.checkIn, checkOut: f.checkOut, guests: f.guests, wPrice: f.wPrice, wComfort: f.wComfort, wLocation: f.wLocation, wRating: f.wRating, freeCancel: f.freeCancel });
    if (f.type) p.set('type', f.type); if (f.budget) p.set('budget', f.budget); if (must.length) p.set('required', must.join(',')); if (nice.length) p.set('preferred', nice.join(','));
    try { last.current = p; setRes(await api('/rooms/search?' + p)); } catch (x) { setErr(errText(x)); setRes(null); } finally { setLoading(false); }
  }
  useEffect(() => subscribe((ev) => { if (ev.type !== 'rooms' && last.current) setStale(true); }), []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const [more, setMore] = useState(false);
  return (<div>
    <Photo src={HERO} className="h-[380px] rounded-3xl shadow-soft sm:h-[460px]">
      <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/40 to-ink/20" />
      <div className="absolute inset-x-0 bottom-0 p-6 pb-20 text-white sm:p-12 sm:pb-24"><p className="mb-2 text-sm tracking-widest text-brass">SEAFRONT · 5-STAR · SINCE 1987</p>
        <h2 className="max-w-xl text-4xl font-semibold leading-tight sm:text-6xl">A quiet kind of luxury, by the water.</h2></div>
    </Photo>
    <form onSubmit={run} className="relative z-10 -mt-14 px-2 sm:px-8">
      <div className="rounded-2xl border border-brass/30 bg-white p-4 shadow-soft sm:p-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_100px_1fr_auto] lg:items-end">
          <div><label className="lbl" htmlFor="ci">Check-in</label><input id="ci" type="date" min={iso(0)} className="field" value={f.checkIn} onChange={set('checkIn')} required /></div>
          <div><label className="lbl" htmlFor="co">Check-out</label><input id="co" type="date" min={f.checkIn} className="field" value={f.checkOut} onChange={set('checkOut')} required /></div>
          <div><label className="lbl" htmlFor="g">Guests</label><input id="g" type="number" min="1" max="10" className="field" value={f.guests} onChange={set('guests')} required /></div>
          <div><label className="lbl" htmlFor="t">Room type</label><select id="t" className="field" value={f.type} onChange={set('type')}><option value="">Any room</option>{['Standard', 'Deluxe', 'Suite', 'Family'].map((t) => <option key={t}>{t}</option>)}</select></div>
          <button className="btn h-[42px] sm:col-span-2 lg:col-span-1" disabled={loading}>{loading ? 'Comparing…' : 'Find my room'}</button>
        </div>
        <button type="button" onClick={() => setMore(!more)} aria-expanded={more} className="mt-3 text-sm font-medium text-tide underline-offset-4 hover:underline">{more ? 'Hide preferences' : 'Refine budget, facilities and priorities'}</button>
        {more && <div className="mt-4 grid gap-5 border-t border-line pt-4 md:grid-cols-2">
          <div className="space-y-4">
            <div><label className="lbl" htmlFor="b">Max budget per night (₹, incl. tax)</label><input id="b" type="number" min="1" className="field" placeholder="No limit" value={f.budget} onChange={set('budget')} /></div>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-[#9a7425]" checked={f.freeCancel} onChange={set('freeCancel')} /> Hide strict cancellation rooms</label>
            <fieldset className="space-y-2"><legend className="lbl">What matters most?</legend>{PRIOS.map(([k, l]) => (<div key={k} className="flex items-center gap-3 text-xs"><span className="w-28">{l}</span><input type="range" min="0" max="5" value={f[k]} onChange={set(k)} className="flex-1 accent-[#9a7425]" aria-label={l} /></div>))}</fieldset></div>
          <div className="space-y-4">
            <fieldset><legend className="lbl">Must have</legend><div className="flex flex-wrap gap-1.5">{AMEN.map((a) => <button type="button" key={a} aria-pressed={must.includes(a)} onClick={() => toggle(must, setMust, a)} className={`rounded-full border px-3 py-1 text-xs transition ${must.includes(a) ? 'border-ink bg-ink text-brass' : 'border-line bg-white hover:border-brass'}`}>{a}</button>)}</div></fieldset>
            <fieldset><legend className="lbl">Nice to have</legend><div className="flex flex-wrap gap-1.5">{AMEN.filter((a) => !must.includes(a)).map((a) => <button type="button" key={a} aria-pressed={nice.includes(a)} onClick={() => toggle(nice, setNice, a)} className={`rounded-full border px-3 py-1 text-xs transition ${nice.includes(a) ? 'border-brass bg-brass text-ink' : 'border-line bg-white hover:border-brass'}`}>{a}</button>)}</div></fieldset></div>
        </div>}
        {err && <p role="alert" className="err">{err}</p>}
      </div>
    </form>
    <section aria-live="polite" className="mt-8">
      {done && <div className="mb-4 rounded-2xl border border-brass bg-white p-5 shadow-card"><p className="font-display text-2xl font-semibold">Your stay is confirmed</p><p className="text-sm">Reference <span className="font-mono font-semibold">{done.ref}</span>. Use your email under “My Bookings” to manage it.</p></div>}
      {stale && <button onClick={run} className="mb-4 w-full rounded-xl bg-brass/20 p-3 text-sm font-medium">Availability changed just now. Refresh results</button>}
      {!res && !loading && <div className="rounded-2xl border border-dashed border-brass/50 bg-white/60 p-10 text-center text-ink/60">Choose your dates and we’ll rank every free room by total cost, facilities, location, ratings and cancellation terms, and tell you why.</div>}
      {res && <>
        <p className="mb-1 text-sm text-ink/60">{res.availableCount} rooms free · {res.results.length} match your needs</p>
        {res.summary && <p className="mb-5 font-display text-2xl font-semibold sm:text-3xl">{res.summary}</p>}
        {!res.results.length && <div className="rounded-2xl bg-white p-6 text-sm shadow-card">No rooms match. {Object.entries(res.excluded).filter(([, n]) => n).map(([k, n]) => `${n} removed by ${k}`).join(', ') || 'No rooms are free on these dates.'} Try relaxing a filter or changing dates.</div>}
        <div className="space-y-5">{res.results.map((r) => (
          <article key={r.room._id} className="grid overflow-hidden rounded-2xl border border-line bg-white shadow-card transition hover:shadow-soft md:grid-cols-[280px_1fr]">
            <Photo src={IMG[r.room.type]} className="h-52 md:h-full">{r.badge && <span className="absolute left-3 top-3 rounded-full bg-ink px-3 py-1 text-xs font-medium text-brass">{r.badge}</span>}</Photo>
            <div className="p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><h3 className="text-2xl font-semibold">{r.room.name}</h3>
                  <p className="text-sm text-ink/60">Room {r.room.number} · {r.room.type} · sleeps {r.room.capacity} · {r.room.distanceKm} km from centre · <span className="text-tide">{r.room.rating}★</span> ({r.room.reviewCount})</p></div>
                <div className="text-right"><div className="font-display text-3xl font-semibold text-tide">{money(r.pricing.total)}</div><div className="text-xs text-ink/60">{r.pricing.nights} night{r.pricing.nights > 1 ? 's' : ''} incl. {money(r.pricing.tax)} tax{r.pricing.discount ? `, −${money(r.pricing.discount)} discount` : ''}</div></div>
              </div>
              <div className="mt-4 grid gap-5 lg:grid-cols-[1fr_220px]">
                <div><h4 className="mb-1 text-sm font-semibold">Why we recommend it</h4><ul className="list-disc space-y-0.5 pl-5 text-sm marker:text-brass">{r.reasons.map((x) => <li key={x}>{x}</li>)}</ul>
                  {r.tradeoffs.length > 0 && <><h4 className="mb-1 mt-3 text-sm font-semibold text-ink/60">Trade-offs</h4><ul className="list-disc space-y-0.5 pl-5 text-sm text-ink/60">{r.tradeoffs.map((x) => <li key={x}>{x}</li>)}</ul></>}
                  <div className="mt-3 flex flex-wrap gap-1">{r.room.amenities.map((a) => <span key={a} className="rounded-full bg-mist px-2.5 py-0.5 text-xs">{a}</span>)}</div></div>
                <div className="rounded-xl bg-ink p-4 text-white"><div className="mb-2 flex items-baseline gap-1"><span className="font-display text-4xl font-semibold text-brass">{r.score}</span><span className="text-xs text-white/60">/ 100 match</span></div>
                  <div className="space-y-1">{Object.entries(r.breakdown).map(([k, v]) => <Bar key={k} label={k} v={v} />)}</div>
                  <button className="btn mt-3 w-full" onClick={() => setPick(r)}>Reserve</button></div>
              </div></div></article>))}</div></>}
    </section>
    {pick && <BookModal r={pick} stay={f} onClose={() => setPick(null)} onDone={(b) => { setPick(null); setDone(b); run(); }} />}
  </div>);
}
