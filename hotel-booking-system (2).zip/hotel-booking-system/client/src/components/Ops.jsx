import { useState, useEffect, useCallback } from 'react';
import { api, money, fmt, errText, subscribe } from '../api.js';
const STATUS = ['Available', 'Reserved', 'Occupied', 'Cleaning', 'Maintenance'];
const COL = { Available: 'bg-emerald-100 text-emerald-800', Reserved: 'bg-sky-100 text-sky-800', Occupied: 'bg-brass/30 text-ink', Cleaning: 'bg-violet-100 text-violet-800', Maintenance: 'bg-red-100 text-red-800' };
const Card = ({ title, children, right }) => (<section className="rounded-2xl border border-line bg-white p-5 shadow-card"><div className="mb-3 flex items-center justify-between"><h2 className="text-xl font-semibold">{title}</h2>{right}</div>{children}</section>);
function Bars({ data, k, unit = '', color = '#c9a24b' }) {
  const max = Math.max(1, ...data.map((d) => d[k]));
  return (<div className="flex h-36 items-end gap-1" role="img" aria-label={k + ' chart'}>{data.map((d) => (<div key={d.date} className="flex flex-1 flex-col items-center justify-end gap-1" title={`${d.date}: ${d[k]}${unit}`}>
    <div className="w-full rounded-t" style={{ height: Math.max(2, (d[k] / max) * 100) + '%', background: color }} /><span className="text-[9px] text-ink/50">{d.date.slice(3)}</span></div>))}</div>);
}
export default function Ops({ adminKey, stats, rooms, bookings, reload }) {
  const [tasks, setTasks] = useState([]), [notes, setNotes] = useState([]), [err, setErr] = useState(''), [wi, setWi] = useState({ roomId: '', name: '', email: '', guests: 1, nights: 1 }), [tk, setTk] = useState({ kind: 'housekeeping', room: '', title: '' });
  const a = adminKey;
  const refresh = useCallback(async () => { try { const [t, n] = await Promise.all([api('/ops/tasks', { admin: a }), api('/ops/notifications', { admin: a })]); setTasks(t); setNotes(n); } catch (x) { setErr(errText(x)); } }, [a]);
  useEffect(() => { refresh(); return subscribe(refresh); }, [refresh]);
  const act = async (fn) => { setErr(''); try { await fn(); await refresh(); reload(); } catch (x) { setErr(errText(x)); } };
  const today = new Date().toISOString().slice(0, 10), active = bookings.filter((b) => b.status === 'confirmed' && !b.checkedOutAt && b.checkIn.slice(0, 10) <= new Date(Date.now() + 2 * 864e5).toISOString().slice(0, 10));
  const unread = notes.filter((n) => !n.read).length;
  return (<div className="space-y-6">
    {err && <p role="alert" className="err">{err}</p>}
    <div className="grid gap-4 md:grid-cols-2">
      <Card title="Revenue by arrival date (₹)"><Bars data={stats.trend} k="revenue" /></Card>
      <Card title="Occupancy trend (%)"><Bars data={stats.trend} k="occupancyPct" unit="%" color="#15130f" /></Card></div>
    <Card title="Room status" right={<div className="flex flex-wrap gap-1">{STATUS.map((s) => <span key={s} className={`rounded-full px-2 py-0.5 text-xs ${COL[s]}`}>{s} {stats.statusCounts[s] || 0}</span>)}</div>}>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">{rooms.filter((r) => r.active).map((r) => (<div key={r._id} className="rounded-xl border border-line p-2 text-xs"><div className="font-semibold">{r.number} <span className="font-normal text-ink/60">{r.type}</span></div>
        <select aria-label={`Status of room ${r.number}`} className={`mt-1 w-full rounded-lg px-1 py-1 ${COL[r.status || 'Available']}`} value={r.status || 'Available'} onChange={(e) => act(() => api(`/ops/rooms/${r._id}/status`, { method: 'PUT', body: { status: e.target.value }, admin: a }))}>{STATUS.map((s) => <option key={s}>{s}</option>)}</select></div>))}</div></Card>
    <Card title="Front desk (arrivals, in-house)"><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-xs text-ink/60"><tr><th className="py-1">Guest</th><th>Room</th><th>Stay</th><th>Payment</th><th></th></tr></thead><tbody>
      {active.map((b) => <tr key={b._id} className="border-t border-line align-top"><td className="py-2">{b.guest.name}<div className="font-mono text-[10px] text-ink/50">{b.ref}</div></td><td>{b.room?.number}</td><td>{fmt(b.checkIn)} → {fmt(b.checkOut)}</td><td>{b.payment?.status || 'pending'}</td>
        <td className="space-x-2 whitespace-nowrap py-2 text-right">
          {!b.checkedInAt && <button className="btn-ghost" onClick={() => act(() => api(`/ops/bookings/${b.ref}/check-in`, { method: 'POST', admin: a }))}>Check in</button>}
          {b.checkedInAt && <button className="btn-ghost" onClick={() => act(() => api(`/ops/bookings/${b.ref}/check-out`, { method: 'POST', admin: a }))}>Check out</button>}
          <button className="btn-ghost" onClick={() => act(() => api(`/ops/bookings/${b.ref}/extend`, { method: 'PUT', body: { checkOut: new Date(new Date(b.checkOut).getTime() + 864e5).toISOString().slice(0, 10) }, admin: a }))}>+1 night</button>
          <button className="btn-ghost" onClick={() => { const n = prompt('Move to room number:'); const r = rooms.find((x) => x.number === (n || '').trim()); if (r) act(() => api(`/ops/bookings/${b.ref}/change-room`, { method: 'PUT', body: { roomId: r._id }, admin: a })); else if (n) setErr('Room number not found'); }}>Change room</button></td></tr>)}
      {!active.length && <tr><td colSpan="5" className="py-4 text-ink/60">No arrivals or in-house guests right now.</td></tr>}</tbody></table></div></Card>
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Walk-in booking (checks in today)"><form className="grid grid-cols-2 gap-2" onSubmit={(e) => { e.preventDefault(); act(() => api('/ops/walk-in', { method: 'POST', admin: a, body: { roomId: wi.roomId, guests: +wi.guests, nights: +wi.nights, guest: { name: wi.name, email: wi.email } } })); }}>
        <select required className="field col-span-2" value={wi.roomId} onChange={(e) => setWi({ ...wi, roomId: e.target.value })} aria-label="Room"><option value="">Select room</option>{rooms.filter((r) => r.active && r.status === 'Available').map((r) => <option key={r._id} value={r._id}>{r.number} {r.name} ({money(r.pricePerNight)})</option>)}</select>
        <input required className="field" placeholder="Guest name" value={wi.name} onChange={(e) => setWi({ ...wi, name: e.target.value })} /><input required type="email" className="field" placeholder="Email" value={wi.email} onChange={(e) => setWi({ ...wi, email: e.target.value })} />
        <input type="number" min="1" className="field" aria-label="Guests" value={wi.guests} onChange={(e) => setWi({ ...wi, guests: e.target.value })} /><input type="number" min="1" className="field" aria-label="Nights" value={wi.nights} onChange={(e) => setWi({ ...wi, nights: e.target.value })} /><button className="btn col-span-2">Check in walk-in guest</button></form></Card>
      <Card title="Notifications" right={<button className="text-xs text-tide underline" onClick={() => act(() => api('/ops/notifications/read', { method: 'PUT', admin: a }))}>Mark all read ({unread})</button>}>
        <ul className="max-h-48 space-y-2 overflow-y-auto text-sm">{notes.map((n) => <li key={n._id} className={`rounded-lg p-2 ${n.read ? 'bg-mist' : 'bg-brass/15'}`}><b>{n.title}</b><div className="text-xs text-ink/70">{n.message}</div></li>)}</ul></Card></div>
    <Card title="Housekeeping and maintenance tasks">
      <form className="mb-3 flex flex-wrap gap-2" onSubmit={(e) => { e.preventDefault(); act(() => api('/ops/tasks', { method: 'POST', admin: a, body: { ...tk, room: tk.room || undefined, priority: 'medium' } })).then(() => setTk({ ...tk, title: '' })); }}>
        <select className="field w-auto" value={tk.kind} onChange={(e) => setTk({ ...tk, kind: e.target.value })} aria-label="Task type"><option value="housekeeping">Housekeeping</option><option value="maintenance">Maintenance issue</option></select>
        <select required className="field w-auto" value={tk.room} onChange={(e) => setTk({ ...tk, room: e.target.value })} aria-label="Room"><option value="">Room</option>{rooms.map((r) => <option key={r._id} value={r._id}>{r.number}</option>)}</select>
        <input required className="field min-w-[200px] flex-1" placeholder="Describe the task or issue" value={tk.title} onChange={(e) => setTk({ ...tk, title: e.target.value })} /><button className="btn">Add</button></form>
      <div className="grid gap-2 md:grid-cols-2">{tasks.map((t) => (<div key={t._id} className="flex items-center justify-between gap-2 rounded-xl border border-line p-3 text-sm"><div><span className={`mr-2 rounded px-1.5 py-0.5 text-[10px] ${t.kind === 'maintenance' ? 'bg-red-100 text-red-800' : 'bg-violet-100 text-violet-800'}`}>{t.kind}</span><b>Room {t.room?.number}</b> · {t.title}<div className="text-xs text-ink/60">{t.priority} priority{t.assignee ? ` · ${t.assignee}` : ''}</div></div>
        <select aria-label="Task status" className="rounded-lg border border-line px-1 py-1 text-xs" value={t.status} onChange={(e) => act(() => api('/ops/tasks/' + t._id, { method: 'PUT', body: { status: e.target.value }, admin: a }))}><option value="open">open</option><option value="in_progress">in progress</option><option value="done">done</option></select></div>))}</div></Card>
  </div>);
}
