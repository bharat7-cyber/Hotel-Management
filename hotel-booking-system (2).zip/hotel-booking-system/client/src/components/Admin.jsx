import { useState, useEffect, useCallback } from 'react';
import Ops from './Ops.jsx';
import { api, money, fmt, errText, subscribe } from '../api.js';
const blank = { number: '', name: '', type: 'Standard', pricePerNight: 3000, capacity: 2, amenities: '', cancellationPolicy: 'moderate', distanceKm: 1, rating: 4, description: '' };
export default function Admin() {
  const [key, setKey] = useState(sessionStorage.getItem('ak') || ''), [ok, setOk] = useState(false), [err, setErr] = useState('');
  const [stats, setStats] = useState(null), [rooms, setRooms] = useState([]), [bookings, setBookings] = useState([]), [form, setForm] = useState(null);
  const load = useCallback(async () => {
    try { const [s, r, b] = await Promise.all([api('/admin/stats', { admin: key }), api('/rooms?all=true'), api('/bookings', { admin: key })]); setStats(s); setRooms(r); setBookings(b); setOk(true); setErr(''); sessionStorage.setItem('ak', key); }
    catch (x) { setOk(false); setErr(errText(x)); }
  }, [key]);
  useEffect(() => ok ? subscribe(load) : undefined, [ok, load]);
  async function saveRoom(e) {
    e.preventDefault();
    const body = { ...form, pricePerNight: +form.pricePerNight, capacity: +form.capacity, distanceKm: +form.distanceKm, rating: +form.rating, amenities: Array.isArray(form.amenities) ? form.amenities : form.amenities.split(',').map((s) => s.trim()).filter(Boolean) };
    delete body._id; delete body.__v; delete body.createdAt; delete body.updatedAt;
    try { await api(form._id ? '/rooms/' + form._id : '/rooms', { method: form._id ? 'PUT' : 'POST', body, admin: key }); setForm(null); load(); } catch (x) { setErr(errText(x)); }
  }
  const del = async (id) => { if (confirm('Delete this room?')) try { await api('/rooms/' + id, { method: 'DELETE', admin: key }); load(); } catch (x) { setErr(errText(x)); } };
  const cancel = async (ref) => { try { await api('/bookings/' + ref, { method: 'DELETE', admin: key }); load(); } catch (x) { setErr(errText(x)); } };
  if (!ok) return (<form onSubmit={(e) => { e.preventDefault(); load(); }} className="mx-auto max-w-sm space-y-3 rounded-2xl bg-white p-6"><h2 className="font-display text-lg font-bold">Admin access</h2>
    <label className="lbl" htmlFor="k">Admin key</label><input id="k" type="password" className="field" value={key} onChange={(e) => setKey(e.target.value)} /><p className="text-xs text-ink/60">Set in server/.env as ADMIN_KEY.</p>{err && <p role="alert" className="err">{err}</p>}<button className="btn w-full">Sign in</button></form>);
  const T = ({ l, v }) => <div className="rounded-xl border border-line bg-white p-4"><div className="text-xs text-ink/60">{l}</div><div className="font-display text-2xl font-extrabold">{v}</div></div>;
  return (<div className="space-y-6">
    {err && <p role="alert" className="err">{err}</p>}
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4"><T l="Occupancy today" v={stats.occupancyPct + '%'} /><T l="Active rooms" v={stats.rooms} /><T l="Upcoming bookings" v={stats.upcomingBookings} /><T l="Confirmed revenue" v={money(stats.revenue)} /></div>
    <Ops adminKey={key} stats={stats} rooms={rooms} bookings={bookings} reload={load} />
    <section className="rounded-2xl border border-line bg-white p-5"><div className="mb-3 flex justify-between"><h2 className="font-display text-lg font-bold">Rooms</h2><button className="btn" onClick={() => setForm({ ...blank })}>Add room</button></div>
      <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-xs text-ink/60"><tr><th className="py-1">No.</th><th>Name</th><th>Type</th><th>Price</th><th>Sleeps</th><th>Policy</th><th></th></tr></thead><tbody>
        {rooms.map((r) => <tr key={r._id} className="border-t border-line"><td className="py-2">{r.number}</td><td>{r.name}{!r.active && ' (inactive)'}</td><td>{r.type}</td><td>{money(r.pricePerNight)}</td><td>{r.capacity}</td><td>{r.cancellationPolicy}</td>
          <td className="space-x-2 text-right"><button className="text-tide underline" onClick={() => setForm({ ...r })}>Edit</button><button className="text-red-700 underline" onClick={() => del(r._id)}>Delete</button></td></tr>)}</tbody></table></div></section>
    {form && <form onSubmit={saveRoom} className="grid gap-3 rounded-2xl border border-tide bg-white p-5 md:grid-cols-4">
      {[['number', 'Room no.'], ['name', 'Name'], ['pricePerNight', 'Price/night', 'number'], ['capacity', 'Capacity', 'number'], ['distanceKm', 'Distance km', 'number'], ['rating', 'Rating', 'number'], ['amenities', 'Amenities (comma separated)']].map(([k, l, t]) => (
        <div key={k}><label className="lbl" htmlFor={'f' + k}>{l}</label><input id={'f' + k} type={t || 'text'} step="any" required={k !== 'amenities'} className="field" value={Array.isArray(form[k]) ? form[k].join(', ') : form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} /></div>))}
      <div><label className="lbl" htmlFor="ft">Type</label><select id="ft" className="field" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{['Standard', 'Deluxe', 'Suite', 'Family'].map((t) => <option key={t}>{t}</option>)}</select></div>
      <div><label className="lbl" htmlFor="fp">Cancellation</label><select id="fp" className="field" value={form.cancellationPolicy} onChange={(e) => setForm({ ...form, cancellationPolicy: e.target.value })}>{['flexible', 'moderate', 'strict'].map((t) => <option key={t}>{t}</option>)}</select></div>
      <div className="flex items-end gap-2"><button className="btn">{form._id ? 'Update' : 'Create'}</button><button type="button" className="btn-ghost" onClick={() => setForm(null)}>Close</button></div></form>}
    <section className="rounded-2xl border border-line bg-white p-5"><h2 className="mb-3 font-display text-lg font-bold">Bookings</h2><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-xs text-ink/60"><tr><th className="py-1">Ref</th><th>Guest</th><th>Room</th><th>Stay</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>
      {bookings.map((b) => <tr key={b._id} className="border-t border-line"><td className="py-2 font-mono text-xs">{b.ref}</td><td>{b.guest.name}</td><td>{b.room?.number}</td><td>{fmt(b.checkIn)} → {fmt(b.checkOut)}</td><td>{money(b.pricing.total)}</td><td>{b.status}</td><td className="text-right">{b.status === 'confirmed' && <button className="text-red-700 underline" onClick={() => cancel(b.ref)}>Cancel</button>}</td></tr>)}</tbody></table></div></section>
  </div>);
}
