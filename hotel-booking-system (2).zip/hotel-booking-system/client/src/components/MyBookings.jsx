import { useState, useEffect } from 'react';
import { api, money, fmt, errText, subscribe } from '../api.js';
export default function MyBookings() {
  const [email, setEmail] = useState(''), [list, setList] = useState(null), [err, setErr] = useState(''), [note, setNote] = useState(''), [edit, setEdit] = useState(null);
  async function load(e) {
    e?.preventDefault(); setErr('');
    try { setList(await api('/bookings?email=' + encodeURIComponent(email.trim()))); } catch (x) { setErr(errText(x)); }
  }
  useEffect(() => subscribe(() => list && load()), [list, email]);
  async function cancel(b) {
    if (!confirm(`Cancel ${b.ref}? Refund: ${money(b.refundIfCancelled)}`)) return;
    try { const r = await api(`/bookings/${b.ref}?email=${encodeURIComponent(email)}`, { method: 'DELETE' }); setNote(`Cancelled. Refund of ${money(r.refundAmount)} will be issued.`); load(); } catch (x) { setErr(errText(x)); }
  }
  async function save(e) {
    e.preventDefault();
    try { await api('/bookings/' + edit.ref, { method: 'PUT', body: { email, checkIn: edit.checkIn, checkOut: edit.checkOut } }); setEdit(null); setNote('Dates updated.'); load(); } catch (x) { setErr(errText(x)); }
  }
  return (<div className="mx-auto max-w-3xl">
    <form onSubmit={load} className="mb-5 flex gap-2"><label htmlFor="em" className="sr-only">Email</label><input id="em" type="email" required className="field" placeholder="Email used for booking" value={email} onChange={(e) => setEmail(e.target.value)} /><button className="btn">Look up</button></form>
    {err && <p role="alert" className="err mb-3">{err}</p>}{note && <p className="mb-3 text-sm text-tide">{note}</p>}
    {list && !list.length && <p className="text-sm text-ink/60">No bookings found for this email.</p>}
    <div className="space-y-3">{list?.map((b) => (<div key={b._id} className="rounded-xl border border-line bg-white p-4">
      <div className="flex flex-wrap justify-between gap-2"><div><b>{b.room?.name}</b> <span className="font-mono text-xs text-ink/60">{b.ref}</span><p className="text-sm">{fmt(b.checkIn)} → {fmt(b.checkOut)} · {b.guests} guests · {money(b.pricing.total)}</p></div>
        <span className={`h-fit rounded px-2 py-0.5 text-xs font-semibold ${b.status === 'confirmed' ? 'bg-tide/10 text-tide' : 'bg-red-100 text-red-700'}`}>{b.status}{b.status === 'cancelled' && ` · refund ${money(b.refundAmount)}`}</span></div>
      {b.status === 'confirmed' && new Date(b.checkIn) > new Date() && <div className="mt-3 flex gap-2"><button className="btn-ghost" onClick={() => setEdit({ ref: b.ref, checkIn: b.checkIn.slice(0, 10), checkOut: b.checkOut.slice(0, 10) })}>Change dates</button><button className="btn-ghost text-red-700" onClick={() => cancel(b)}>Cancel (refund {money(b.refundIfCancelled)})</button></div>}
      {edit?.ref === b.ref && <form onSubmit={save} className="mt-3 flex flex-wrap items-end gap-2"><input type="date" className="field w-auto" value={edit.checkIn} onChange={(e) => setEdit({ ...edit, checkIn: e.target.value })} /><input type="date" className="field w-auto" value={edit.checkOut} onChange={(e) => setEdit({ ...edit, checkOut: e.target.value })} /><button className="btn">Save</button></form>}
    </div>))}</div></div>);
}
