import { useState } from 'react';
import { api, money, fmt, errText } from '../api.js';
const mask = (s) => s.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
export function Invoice({ b, roomName, onClose }) {
  const p = b.pricing;
  return (<div className="space-y-3 text-sm" id="invoice">
    <div className="rounded-xl bg-ink p-4 text-white"><p className="font-display text-2xl text-brass">Booking confirmed</p><p>Reference <b className="font-mono">{b.ref}</b> · Invoice INV-{b.ref.slice(3)}</p></div>
    <p><b>{roomName}</b> · {fmt(b.checkIn)} → {fmt(b.checkOut)} · {b.guests} guest(s)<br />{b.guest.name} · {b.guest.email}</p>
    <table className="w-full"><tbody>
      <tr><td>Room charges ({p.nights} nights)</td><td className="text-right">{money(p.subtotal)}</td></tr>
      {p.discount > 0 && <tr><td>Long-stay discount</td><td className="text-right">−{money(p.discount)}</td></tr>}
      {p.couponDiscount > 0 && <tr><td>Coupon {b.couponCode}</td><td className="text-right text-tide">−{money(p.couponDiscount)}</td></tr>}
      <tr><td>GST (12%)</td><td className="text-right">{money(p.tax)}</td></tr>
      <tr className="border-t border-line font-semibold"><td>Total</td><td className="text-right">{money(p.total)}</td></tr></tbody></table>
    <p className="rounded bg-mist p-2 text-xs">Payment: {b.payment?.status === 'paid' ? `Paid via ${b.payment.method.toUpperCase()} · ${b.payment.txnId}` : 'Pay at hotel on arrival'}</p>
    <div className="flex justify-end gap-2 print:hidden"><button className="btn-ghost" onClick={() => window.print()}>Print invoice</button><button className="btn" onClick={onClose}>Done</button></div></div>);
}
export default function BookModal({ r, stay, onClose, onDone }) {
  const [g, setG] = useState({ name: '', email: '', phone: '' }), [errs, setErrs] = useState({}), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false);
  const [pay, setPay] = useState('pay_at_hotel'), [card, setCard] = useState({ num: '', exp: '', cvv: '', upi: '' }), [code, setCode] = useState(''), [cp, setCp] = useState(null), [made, setMade] = useState(null);
  const total = cp ? cp.total : r.pricing.total;
  async function applyCode() {
    setMsg(''); if (!code.trim()) return setCp(null);
    try { setCp(await api('/ops/coupons/validate', { method: 'POST', body: { code, total: r.pricing.total, nights: r.pricing.nights } })); } catch (x) { setCp(null); setMsg(errText(x)); }
  }
  function check() {
    const e = {};
    if (g.name.trim().length < 2) e.name = 'Enter your full name';
    if (!/^\S+@\S+\.\S+$/.test(g.email)) e.email = 'Enter a valid email';
    if (g.phone && !/^[+\d][\d\s-]{6,14}$/.test(g.phone)) e.phone = 'Enter a valid phone number';
    if (pay === 'card') { if (card.num.replace(/\D/g, '').length !== 16) e.num = 'Enter 16 digit card number'; if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(card.exp)) e.exp = 'Use MM/YY'; if (!/^\d{3}$/.test(card.cvv)) e.cvv = '3 digits'; }
    if (pay === 'upi' && !/^[\w.-]+@[\w]+$/.test(card.upi)) e.upi = 'Enter a valid UPI ID (name@bank)';
    setErrs(e); return !Object.keys(e).length;
  }
  async function submit(ev) {
    ev.preventDefault(); if (!check()) return; setBusy(true); setMsg('');
    try { setMade(await api('/bookings', { method: 'POST', body: { roomId: r.room._id, guests: Number(stay.guests), checkIn: stay.checkIn, checkOut: stay.checkOut, guest: g, paymentMethod: pay, couponCode: cp ? code : '' } })); }
    catch (x) { setMsg(errText(x)); } finally { setBusy(false); }
  }
  const F = ({ k, l, t = 'text', s = g, set = setG, ph }) => (<div><label className="lbl" htmlFor={'m' + k}>{l}</label><input id={'m' + k} type={t} placeholder={ph} className="field" value={s[k]} onChange={(e) => set({ ...s, [k]: k === 'num' ? mask(e.target.value) : e.target.value })} />{errs[k] && <p className="err">{errs[k]}</p>}</div>);
  return (<div className="fixed inset-0 z-30 flex items-start justify-center overflow-y-auto bg-ink/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Confirm booking">
    {made ? <div className="my-6 w-full max-w-md rounded-2xl border border-brass/30 bg-white p-6 shadow-soft"><Invoice b={made} roomName={r.room.name} onClose={() => onDone(made)} /></div> :
    <form onSubmit={submit} noValidate className="my-6 w-full max-w-md space-y-3 rounded-2xl border border-brass/30 bg-white p-6 shadow-soft">
      <h2 className="text-2xl font-semibold">Reserve {r.room.name}</h2>
      <p className="text-sm text-ink/70">{stay.checkIn} → {stay.checkOut} · {stay.guests} guest(s)</p>
      <p className="rounded bg-mist p-2 text-xs">{r.reasons[r.reasons.length - 1]}</p>
      <F k="name" l="Full name" /><F k="email" l="Email" t="email" /><F k="phone" l="Phone (optional)" t="tel" />
      <div><label className="lbl" htmlFor="cp">Coupon code</label><div className="flex gap-2"><input id="cp" className="field" placeholder="e.g. WELCOME10" value={code} onChange={(e) => { setCode(e.target.value); setCp(null); }} /><button type="button" className="btn-ghost" onClick={applyCode}>Apply</button></div>
        {cp && <p className="mt-1 text-xs text-tide">{cp.code} applied: you save {money(cp.couponDiscount)}</p>}</div>
      <fieldset><legend className="lbl">Payment (demo, no real charge)</legend><div className="flex gap-1.5">{[['pay_at_hotel', 'Pay at hotel'], ['upi', 'UPI'], ['card', 'Card']].map(([k, l]) => <button type="button" key={k} aria-pressed={pay === k} onClick={() => setPay(k)} className={`flex-1 rounded-xl border px-2 py-2 text-sm ${pay === k ? 'border-ink bg-ink text-brass' : 'border-line'}`}>{l}</button>)}</div></fieldset>
      {pay === 'card' && <div className="grid grid-cols-2 gap-2"><div className="col-span-2"><F k="num" l="Card number" s={card} set={setCard} ph="4111 1111 1111 1111" /></div><F k="exp" l="Expiry" s={card} set={setCard} ph="MM/YY" /><F k="cvv" l="CVV" s={card} set={setCard} /></div>}
      {pay === 'upi' && <F k="upi" l="UPI ID" s={card} set={setCard} ph="name@okbank" />}
      {msg && <p role="alert" className="err">{msg}</p>}
      <div className="flex items-center justify-between gap-2"><div><div className="text-xs text-ink/60">Total incl. tax</div><div className="font-display text-2xl font-semibold text-tide">{money(total)}</div></div>
        <div className="flex gap-2"><button type="button" className="btn-ghost" onClick={onClose}>Back</button><button className="btn" disabled={busy}>{busy ? 'Processing…' : pay === 'pay_at_hotel' ? 'Confirm booking' : 'Pay & confirm'}</button></div></div>
    </form>}</div>);
}
