export const money = (n) => '₹' + Math.round(n).toLocaleString('en-IN');
export const fmt = (d) => new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', timeZone: 'UTC' });
export async function api(path, { method = 'GET', body, admin } = {}) {
  const res = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(admin ? { 'x-admin-key': admin } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data = {}; try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text.slice(0, 120) }; }
  if (!res.ok) { const e = new Error(data.error || (res.status >= 500 ? 'Cannot reach the booking server. Check that the API is running on port 5000 and MongoDB is connected.' : `Request failed (${res.status})`)); e.details = data.details; e.status = res.status; throw e; }
  return data;
}
export const errText = (e) => e.details?.length ? e.details.map((d) => d.message || d.field).join('. ') : e.message;
// Real-time availability: server-sent events trigger refetches.
export function subscribe(onEvent) {
  const es = new EventSource('/api/events');
  es.onmessage = (m) => onEvent(JSON.parse(m.data));
  return () => es.close();
}
