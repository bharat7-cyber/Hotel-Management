export default { content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { fontFamily: { display: ['"Cormorant Garamond"', 'Georgia', 'serif'], sans: ['Jost', 'system-ui', 'sans-serif'] },
    boxShadow: { soft: '0 10px 40px -12px rgba(20,17,13,.25)', card: '0 2px 18px -4px rgba(20,17,13,.12)' },
    colors: { ink: '#15130f', tide: '#9a7425', brass: '#c9a24b', mist: '#f5f3ee', line: '#e6dfd0' } } }, plugins: [] };
