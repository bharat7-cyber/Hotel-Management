# StayEase – Hotel Booking Web App

Express + SQLite (better-sqlite3) + vanilla JS single-page client. The database is created and seeded automatically on first start.

## Setup (Node 20+)
```bash
npm install
npm start            # http://localhost:3000
npm test             # 16 API tests on a temporary database
npm run seed         # wipe and re-seed demo data
```
Logins: **admin@stayease.com / admin123** · **demo@stayease.com / demo123**

## Folder structure
```
client/  index.html, css/styles.css, js/ (app, api, ui, state, session, auth, components, bus), js/pages/ (home, listing, hotel, booking, confirmation, myBookings, admin)
server/  index.js, app.js, db/ (database.js schema, seed.js), routes/, controllers/, middleware/, utils/ (bookingService, availability, pricing, dates, events)
tests/   api.test.js
```

## API (prefix /api; L = login, A = admin)
- POST /auth/register, /auth/login · GET /auth/me (L)
- GET /hotels?q&checkIn&checkOut&guests&rooms&minPrice&maxPrice&stars&minRating&amenities&sort&page&limit
- GET /hotels/cities · GET /hotels/:id?checkIn&checkOut&rooms&guests
- POST /hotels (A) · PUT, DELETE /hotels/:id (A)
- GET, POST /hotels/:id/reviews (POST: L, completed stay only)
- POST /hotels/:hotelId/rooms (A) · GET /rooms/:id · GET /rooms/:id/availability · PUT, DELETE /rooms/:id (A)
- GET /coupons · POST /bookings/quote · POST /bookings (L) · GET /bookings/mine (L) · GET /bookings/:ref (L) · DELETE /bookings/:ref (L, cancel)
- GET /admin/stats, /admin/hotels, /admin/hotels/:id/rooms, /admin/bookings, /admin/guests, /admin/reviews (A) · PUT /admin/bookings/:id {status} (A) · DELETE /admin/reviews/:id (A)
- GET /events (Server-Sent Events for live availability)

Errors: `{ "error": "message" }` with 400, 401, 403, 404, 409 (sold out/conflict), 429.

## Rules
Price = rate × nights × rooms − long-stay discount (3+ nights 5%, 5+ 10%, 7+ 15%) − coupon (WELCOME10, STAY15, FLAT500), then GST per room-night tariff (≤1000: 0%, ≤7500: 12%, above: 18%). Refund: 100% if cancelled 2+ days before check-in, 50% one day before, 0 on arrival day.

## Test cases
TC01 CRUD · TC02 roles · TC03 search/filter/sort · TC04 price maths · TC05 validation · TC06 booking ID · TC07 overlap matrix · TC08 live availability · TC09 concurrent bookings · TC10 ownership · TC11 cancel/refund · TC12 auth errors · TC13 reviews · TC14 admin stats/reinstate · TC15 safe update/delete · TC16 404/bad JSON.

## Viva notes
- Flow: SPA → fetch → routes → controllers → SQLite; business rules in utils/.
- No double booking: a stay occupies nights [check-in, check-out). Availability = units − busiest overlapping night. Check + insert run in one BEGIN IMMEDIATE transaction, so SQLite serialises writers.
- Real time: each booking/cancel broadcasts an SSE event; open pages refresh.
- Security: scrypt passwords, HMAC tokens, parameterised SQL, HTML escaping, role middleware, login rate limit.
- Hotels/rooms with history are hidden (soft delete) so revenue and history stay correct.
