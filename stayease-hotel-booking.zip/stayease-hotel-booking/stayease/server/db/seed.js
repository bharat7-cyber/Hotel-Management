// Creates realistic demo data. Runs automatically on first start; `npm run seed` wipes and re-creates it.
const db = require('./database');
const { hashPassword } = require('../middleware/auth');
const { createBooking, cancelBooking } = require('../utils/bookingService');
const { today, addDays } = require('../utils/dates');

const U = (id) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=1200&q=70`;
const HOTEL_IMGS = ['1566073771259-6a8506099945', '1551882547-ff40c63fe5fa', '1520250497591-112f2f40a3f4', '1542314831-068cd1dbfeeb',
  '1564501049412-61c2a3083791', '1445019980597-93fa8acb246c', '1571896349842-33c89424de2d', '1455587734955-081b22074882',
  '1496417263034-38ec4f0b665a', '1561501900-3701fa6a0864', '1584132967334-10e028bd69f7', '1540541338287-41700207dee6'].map(U);
const ROOM_IMGS = ['1582719478250-c89cae4dc85b', '1611892440504-42a792e24d32', '1590490360182-c33d57733427', '1618773928121-c32242e63f39',
  '1578683010236-d716f9a3f461', '1631049307264-da0ec9d70304', '1596394516093-501ba68a0ba6', '1560448204-e02f11c3d0e2'].map(U);

// name, city, state, stars, base price (₹/night), address, description, amenities
const HOTELS = [
  ['The Marine Grand', 'Mumbai', 'Maharashtra', 5, 9500, 'Netaji Subhash Chandra Rd, Marine Drive', 'A landmark sea-facing hotel on Marine Drive with art-deco interiors, a rooftop lounge and views of the Queen\'s Necklace.', 'wifi pool spa gym restaurant bar ac breakfast parking laundry'],
  ['Juhu Beach Residency', 'Mumbai', 'Maharashtra', 4, 6200, 'Juhu Tara Road, Juhu', 'Steps from Juhu beach, popular with families and film-city visitors. Rooftop pool and an all-day diner.', 'wifi pool gym restaurant ac breakfast parking'],
  ['Baga Sands Resort', 'Goa', 'Goa', 4, 5800, 'Baga Beach Road, Calangute', 'A lively beach resort with palm-lined pools, a beach shack and easy access to Goa\'s famous nightlife.', 'wifi pool bar restaurant ac breakfast spa shuttle'],
  ['Palolem Palms Retreat', 'Goa', 'Goa', 3, 3500, 'Palolem Beach, Canacona', 'Quiet South Goa cottages under coconut palms, ten minutes\' walk to the beach. Great for slow holidays.', 'wifi restaurant ac breakfast pet laundry'],
  ['Amber Fort Haveli', 'Jaipur', 'Rajasthan', 5, 8800, 'Amer Road, near Amber Fort', 'A restored 18th-century haveli with courtyards, frescoes, camel-cart arrivals and a candle-lit rooftop dinner.', 'wifi pool spa restaurant bar ac breakfast parking shuttle'],
  ['Pink City Inn', 'Jaipur', 'Rajasthan', 3, 2400, 'MI Road, Jaipur', 'A friendly, well-run budget hotel inside the old city walls, close to Hawa Mahal and the bazaars.', 'wifi restaurant ac breakfast parking'],
  ['Lake Pichola Palace Stay', 'Udaipur', 'Rajasthan', 5, 12000, 'Lake Pichola Ghat, City Palace Road', 'Wake up to the City Palace across the water. Marble terraces, boat transfers and a heritage spa.', 'wifi pool spa gym restaurant bar ac breakfast shuttle laundry'],
  ['Connaught Crown', 'New Delhi', 'Delhi', 5, 10500, 'Barakhamba Road, Connaught Place', 'A business-class landmark in the heart of Delhi with a skyline bar, wellness floor and meeting suites.', 'wifi pool spa gym restaurant bar ac breakfast parking laundry'],
  ['Karol Bagh Comfort', 'New Delhi', 'Delhi', 3, 2800, 'Arya Samaj Road, Karol Bagh', 'Clean, practical rooms two minutes from the metro. Ideal for short business trips and shopping weekends.', 'wifi restaurant ac breakfast laundry'],
  ['Indiranagar Urban Suites', 'Bengaluru', 'Karnataka', 4, 5200, '100 Feet Road, Indiranagar', 'Design-led suites above the city\'s best cafés and microbreweries, with a co-working lounge.', 'wifi gym restaurant bar ac breakfast parking laundry'],
  ['Whitefield Tech Park Hotel', 'Bengaluru', 'Karnataka', 3, 3200, 'ITPL Main Road, Whitefield', 'Built for work trips: fast WiFi, quiet rooms and a shuttle to the major tech parks.', 'wifi gym restaurant ac breakfast parking shuttle'],
  ['Backwater Bliss', 'Kochi', 'Kerala', 4, 6500, 'Marine Drive, Ernakulam', 'Kerala-style rooms on the backwaters with Ayurvedic massages, houseboat day trips and seafood dinners.', 'wifi pool spa restaurant ac breakfast shuttle'],
  ['Deccan Pearl', 'Hyderabad', 'Telangana', 4, 4800, 'Banjara Hills Road No. 12', 'Nizami-inspired interiors, a biryani kitchen the locals queue for, and a spa by the pool.', 'wifi pool spa gym restaurant ac breakfast parking'],
  ['Orange City Heritage', 'Nagpur', 'Maharashtra', 4, 3900, 'Wardha Road, Civil Lines', 'A warm, modern hotel with Vidarbha cuisine, a rooftop restaurant and easy access to the airport and the city centre.', 'wifi pool gym restaurant bar ac breakfast parking'],
  ['Himalayan Pine Lodge', 'Shimla', 'Himachal Pradesh', 3, 3600, 'The Mall Road, Shimla', 'Pine-wood rooms with fireplaces and snow-peak views, five minutes from Mall Road on foot.', 'wifi restaurant breakfast parking pet laundry'],
  ['Ganga Ghat View', 'Varanasi', 'Uttar Pradesh', 3, 2200, 'Dashashwamedh Ghat Road', 'A rooftop-terrace hotel above the ghats. Watch the evening aarti from your balcony.', 'wifi restaurant ac breakfast shuttle'],
];

const ROOM_TYPES = [
  { name: 'Standard Room', type: 'standard', mult: 1, cap: 2, units: [7, 10], beds: '1 Queen bed or 2 Twin beds', size: 24, am: ['wifi', 'ac'] },
  { name: 'Deluxe Room', type: 'deluxe', mult: 1.35, cap: 3, units: [4, 8], beds: '1 King bed + sofa bed', size: 32, am: ['wifi', 'ac', 'breakfast'] },
  { name: 'Executive Suite', type: 'suite', mult: 2.2, cap: 4, units: [2, 4], beds: '1 King bed + living area', size: 52, am: ['wifi', 'ac', 'breakfast', 'laundry'] },
];

const COMMENTS = {
  5: ['Spotless rooms and the staff went out of their way. Would stay again.', 'Brilliant location, great breakfast and a really comfortable bed.', 'Exceeded expectations. Check-in took two minutes and the view was stunning.', 'Perfect for a family trip. Kids loved the pool.'],
  4: ['Very good value. Rooms are clean and service is quick; breakfast could have more variety.', 'Lovely property and friendly staff. A little noisy on the weekend.', 'Comfortable stay, good WiFi and a great location.'],
  3: ['Decent for the price. Rooms are a bit dated but clean.', 'Good location, average food. Staff were helpful with late check-in.'],
};

function mulberry32(a) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function wipe() {
  db.pragma('foreign_keys = OFF');
  for (const t of ['reviews', 'guests', 'bookings', 'rooms', 'hotels', 'users', 'sqlite_sequence']) db.exec(`DELETE FROM ${t}`);
  db.pragma('foreign_keys = ON');
}

function seed() {
  const rnd = mulberry32(2026);
  const pick = (a) => a[Math.floor(rnd() * a.length)];
  const between = (a, b) => a + Math.floor(rnd() * (b - a + 1));
  const t = today();

  // ---- users
  const addUser = db.prepare('INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?,?,?,?,?)');
  const admin = Number(addUser.run('Site Admin', 'admin@stayease.com', hashPassword('admin123'), 'admin', addDays(t, -200) + ' 09:00:00').lastInsertRowid);
  const demo = Number(addUser.run('Aarav Mehta', 'demo@stayease.com', hashPassword('demo123'), 'user', addDays(t, -120) + ' 09:00:00').lastInsertRowid);
  const people = [['Priya Nair', 'priya.nair@example.com'], ['Rohan Deshmukh', 'rohan.d@example.com'], ['Sneha Kulkarni', 'sneha.k@example.com'],
    ['Imran Shaikh', 'imran.s@example.com'], ['Ananya Iyer', 'ananya.iyer@example.com'], ['Vikram Singh', 'vikram.singh@example.com'],
    ['Neha Gupta', 'neha.gupta@example.com'], ['Karthik Reddy', 'karthik.r@example.com']];
  const users = [{ id: demo, name: 'Aarav Mehta', email: 'demo@stayease.com' }];
  for (const [n, e] of people) users.push({ id: Number(addUser.run(n, e, hashPassword('demo123'), 'user', addDays(t, -between(20, 150)) + ' 10:00:00').lastInsertRowid), name: n, email: e });

  // ---- hotels + rooms
  const addHotel = db.prepare(`INSERT INTO hotels (name, city, state, address, description, stars, image, gallery, amenities) VALUES (?,?,?,?,?,?,?,?,?)`);
  const addRoom = db.prepare(`INSERT INTO rooms (hotel_id, name, type, price_per_night, capacity, total_units, beds, size_sqm, image, amenities) VALUES (?,?,?,?,?,?,?,?,?,?)`);
  const hotelIds = [];
  HOTELS.forEach(([name, city, state, stars, price, address, desc, am], i) => {
    const gallery = [1, 2, 3, 4].map((k) => HOTEL_IMGS[(i + k * 3) % HOTEL_IMGS.length]);
    const id = Number(addHotel.run(name, city, state, address, desc, stars, HOTEL_IMGS[i % HOTEL_IMGS.length], JSON.stringify(gallery), JSON.stringify(am.split(' '))).lastInsertRowid);
    hotelIds.push(id);
    ROOM_TYPES.forEach((rt, k) => {
      const p = Math.round((price * rt.mult) / 50) * 50;
      const amen = [...new Set([...rt.am, ...(stars >= 4 ? ['breakfast'] : [])])];
      addRoom.run(id, `${rt.name}`, rt.type, p, rt.cap, between(rt.units[0], rt.units[1]), rt.beds, rt.size + (stars - 3) * 3,
        ROOM_IMGS[(i + k) % ROOM_IMGS.length], JSON.stringify(amen));
    });
  });
  const rooms = db.prepare('SELECT * FROM rooms').all();
  const guestsFor = (u) => [{ name: u.name, email: u.email, phone: `9${between(100000000, 899999999)}` }];
  const book = (user, room, ci, nights, extra = {}) => {
    try {
      return createBooking(user.id, {
        roomId: room.id, checkIn: ci, checkOut: addDays(ci, nights), rooms: extra.rooms || 1,
        adults: Math.min(extra.adults || between(1, room.capacity), room.capacity * (extra.rooms || 1)), children: 0,
        coupon: extra.coupon || '', guests: guestsFor(user), specialRequests: extra.note || '',
      }, { allowPast: true, silent: true, createdAt: `${addDays(ci, -between(3, 25))} ${String(between(8, 21)).padStart(2, '0')}:${String(between(0, 59)).padStart(2, '0')}:00` });
    } catch { return null; }
  };
  const roomOf = (hotelIdx, k) => rooms.find((r) => r.hotel_id === hotelIds[hotelIdx] && r.type === ROOM_TYPES[k].type);
  const demoUser = users[0];

  // ---- demo user's trips (so "My Bookings" has something in every tab)
  const past1 = book(demoUser, roomOf(0, 1), addDays(t, -34), 2, { adults: 2, note: 'High floor, sea view please.' });
  book(demoUser, roomOf(4, 0), addDays(t, -52), 3, { adults: 2 });
  book(demoUser, roomOf(2, 1), addDays(t, 12), 3, { adults: 2, coupon: 'WELCOME10' });
  book(demoUser, roomOf(6, 2), addDays(t, 31), 2, { adults: 3, note: 'Celebrating our anniversary.' });
  const cx = book(demoUser, roomOf(7, 0), addDays(t, 20), 2, { adults: 2 });
  if (cx) cancelBooking(cx.ref, { id: demoUser.id, role: 'user' }, { force: true, refundPct: 100 });
  if (past1) db.prepare('INSERT INTO reviews (hotel_id, user_id, booking_id, rating, comment, created_at) VALUES (?,?,?,?,?,?)')
    .run(past1.hotel.id, demoUser.id, past1.id, 5, 'Sea-view room was exactly as promised. Breakfast on the terrace was the highlight.', addDays(t, -31) + ' 11:00:00');

  // ---- random history: some past stays, some upcoming
  for (let i = 0; i < 90; i++) {
    const user = pick(users.slice(1));
    const ci = addDays(t, between(-75, 55));
    const b = book(user, pick(rooms), ci, between(1, 5), { rooms: rnd() < 0.8 ? 1 : 2, coupon: rnd() < 0.2 ? 'WELCOME10' : '' });
    if (b && rnd() < 0.12) {
      if (ci >= t) cancelBooking(b.ref, { id: user.id, role: 'user' }, { refundPct: 100 });
      else cancelBooking(b.ref, { id: user.id, role: 'user' }, { force: true, refundPct: 0 });
    }
  }
  // ---- "almost sold out" suites next week so urgency labels are visible
  [0, 2, 4, 6, 7].forEach((hi, n) => {
    const suite = roomOf(hi, 2);
    const ci = addDays(t, 6 + n);
    const free = db.prepare('SELECT total_units FROM rooms WHERE id = ?').get(suite.id).total_units;
    for (let k = 0; k < free - 1; k++) book(users[1 + ((k + n) % (users.length - 1))], suite, ci, 3, { adults: 2 });
  });

  // ---- reviews (a mix of linked-to-booking and general)
  const add = db.prepare('INSERT OR IGNORE INTO reviews (hotel_id, user_id, booking_id, rating, comment, created_at) VALUES (?,?,?,?,?,?)');
  const doneStays = db.prepare(`SELECT id, hotel_id, user_id, check_out FROM bookings WHERE status='CONFIRMED' AND check_out < ? AND user_id != ?`).all(t, demo);
  for (const s of doneStays) {
    if (rnd() < 0.55) {
      const r = rnd() < 0.55 ? 5 : rnd() < 0.7 ? 4 : 3;
      add.run(s.hotel_id, s.user_id, s.id, r, pick(COMMENTS[r]), `${addDays(s.check_out, between(0, 3))} 12:00:00`);
    }
  }
  for (const hid of hotelIds) {
    for (let k = 0; k < between(5, 9); k++) {
      const r = rnd() < 0.5 ? 5 : rnd() < 0.75 ? 4 : 3;
      add.run(hid, pick(users.slice(1)).id, null, r, pick(COMMENTS[r]), `${addDays(t, -between(5, 160))} 12:00:00`);
    }
  }
  return { admin, hotels: hotelIds.length };
}

function seedIfEmpty() {
  if (db.prepare('SELECT COUNT(*) AS c FROM hotels').get().c === 0) {
    seed();
    console.log('✔ Database seeded with demo data');
  }
}

module.exports = { seedIfEmpty, seed, wipe };

if (require.main === module) {
  if (process.argv.includes('--reset')) wipe();
  seedIfEmpty();
  console.log('Admin: admin@stayease.com / admin123   |   Demo user: demo@stayease.com / demo123');
}
