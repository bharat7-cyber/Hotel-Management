// Opens the SQLite file and creates all tables (safe to run on every start).
const Database = require('better-sqlite3');
const path = require('path');

const file = process.env.DB_PATH || path.join(__dirname, 'hotel.sqlite');
const db = new Database(file);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hotels (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  city        TEXT NOT NULL,
  state       TEXT NOT NULL DEFAULT '',
  address     TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  stars       INTEGER NOT NULL DEFAULT 3 CHECK (stars BETWEEN 1 AND 5),
  image       TEXT NOT NULL DEFAULT '',
  gallery     TEXT NOT NULL DEFAULT '[]',
  amenities   TEXT NOT NULL DEFAULT '[]',
  active      INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rooms (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id        INTEGER NOT NULL REFERENCES hotels(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  type            TEXT NOT NULL DEFAULT 'standard',
  price_per_night REAL NOT NULL CHECK (price_per_night > 0),
  capacity        INTEGER NOT NULL CHECK (capacity BETWEEN 1 AND 10),
  total_units     INTEGER NOT NULL CHECK (total_units >= 1),
  beds            TEXT NOT NULL DEFAULT '',
  size_sqm        INTEGER NOT NULL DEFAULT 20,
  image           TEXT NOT NULL DEFAULT '',
  amenities       TEXT NOT NULL DEFAULT '[]',
  active          INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS bookings (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_ref      TEXT NOT NULL UNIQUE,
  user_id          INTEGER NOT NULL REFERENCES users(id),
  hotel_id         INTEGER NOT NULL REFERENCES hotels(id),
  room_id          INTEGER NOT NULL REFERENCES rooms(id),
  check_in         TEXT NOT NULL,
  check_out        TEXT NOT NULL,
  nights           INTEGER NOT NULL,
  rooms_count      INTEGER NOT NULL CHECK (rooms_count >= 1),
  adults           INTEGER NOT NULL CHECK (adults >= 1),
  children         INTEGER NOT NULL DEFAULT 0,
  base_amount      REAL NOT NULL,
  discount_amount  REAL NOT NULL DEFAULT 0,
  coupon_code      TEXT,
  tax_amount       REAL NOT NULL,
  total_amount     REAL NOT NULL,
  refund_amount    REAL NOT NULL DEFAULT 0,
  status           TEXT NOT NULL DEFAULT 'CONFIRMED' CHECK (status IN ('CONFIRMED','CANCELLED')),
  special_requests TEXT NOT NULL DEFAULT '',
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  cancelled_at     TEXT,
  CHECK (check_out > check_in)
);

CREATE TABLE IF NOT EXISTS guests (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL DEFAULT '',
  phone      TEXT NOT NULL DEFAULT '',
  is_primary INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS reviews (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  hotel_id   INTEGER NOT NULL REFERENCES hotels(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  booking_id INTEGER UNIQUE REFERENCES bookings(id) ON DELETE SET NULL,
  rating     INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment    TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_rooms_hotel     ON rooms(hotel_id);
CREATE INDEX IF NOT EXISTS idx_bookings_room   ON bookings(room_id, check_in, check_out);
CREATE INDEX IF NOT EXISTS idx_bookings_user   ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_hotel  ON bookings(hotel_id);
CREATE INDEX IF NOT EXISTS idx_guests_booking  ON guests(booking_id);
CREATE INDEX IF NOT EXISTS idx_reviews_hotel   ON reviews(hotel_id);
`);

module.exports = db;
