const express = require('express');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const rateLimit = require('../middleware/rateLimit');
const { addClient } = require('../utils/events');
const auth = require('../controllers/authController');
const hotels = require('../controllers/hotelsController');
const rooms = require('../controllers/roomsController');
const bookings = require('../controllers/bookingsController');
const admin = require('../controllers/adminController');

const api = express.Router();

// --- Auth
const limiter = rateLimit({ windowMs: 60000, max: 40 });
api.post('/auth/register', limiter, auth.register);
api.post('/auth/login', limiter, auth.login);
api.get('/auth/me', requireAuth, auth.me);

// --- Hotels (public read, admin write)
api.get('/hotels', hotels.list);
api.get('/hotels/cities', hotels.cities);
api.get('/hotels/:id', hotels.getOne);
api.get('/hotels/:id/reviews', hotels.reviewsOf);
api.post('/hotels/:id/reviews', requireAuth, hotels.addReview);
api.post('/hotels', requireAdmin, hotels.create);
api.put('/hotels/:id', requireAdmin, hotels.update);
api.delete('/hotels/:id', requireAdmin, hotels.remove);

// --- Rooms
api.post('/hotels/:hotelId/rooms', requireAdmin, rooms.create);
api.get('/rooms/:id', rooms.getOne);
api.get('/rooms/:id/availability', rooms.availability);
api.put('/rooms/:id', requireAdmin, rooms.update);
api.delete('/rooms/:id', requireAdmin, rooms.remove);

// --- Bookings
api.get('/coupons', bookings.coupons);
api.post('/bookings/quote', bookings.quote);
api.post('/bookings', requireAuth, bookings.create);
api.get('/bookings/mine', requireAuth, bookings.mine);
api.get('/bookings/:ref', requireAuth, bookings.getOne);
api.delete('/bookings/:ref', requireAuth, bookings.cancel);

// --- Admin
api.get('/admin/stats', requireAdmin, admin.stats);
api.get('/admin/hotels', requireAdmin, admin.hotels);
api.get('/admin/hotels/:hotelId/rooms', requireAdmin, admin.rooms);
api.get('/admin/bookings', requireAdmin, admin.bookings);
api.put('/admin/bookings/:id', requireAdmin, admin.updateBooking);
api.get('/admin/guests', requireAdmin, admin.guests);
api.get('/admin/reviews', requireAdmin, admin.reviews);
api.delete('/admin/reviews/:id', requireAdmin, admin.deleteReview);

// --- Live availability stream (Server-Sent Events)
api.get('/events', (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  res.flushHeaders();
  res.write('retry: 3000\n\n');
  addClient(res);
});

module.exports = api;
