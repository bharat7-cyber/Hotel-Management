// Availability = total units of a room type minus the busiest night's booked units in the range.
// A stay occupies nights [check_in, check_out): the check-out day is free for the next guest.
const db = require('../db/database');
const { nightsOf } = require('./dates');

function peak(rows, ci, co) {
  let max = 0;
  for (const night of nightsOf(ci, co)) {
    let used = 0;
    for (const b of rows) if (b.check_in <= night && night < b.check_out) used += b.rooms_count;
    if (used > max) max = used;
  }
  return max;
}

const overlapSql = `SELECT check_in, check_out, rooms_count FROM bookings
  WHERE room_id = ? AND status = 'CONFIRMED' AND check_in < ? AND check_out > ?`;

function roomAvailability(roomId, ci, co) {
  const room = db.prepare('SELECT total_units FROM rooms WHERE id = ?').get(roomId);
  if (!room) return 0;
  const rows = db.prepare(overlapSql).all(roomId, co, ci);
  return Math.max(0, room.total_units - peak(rows, ci, co));
}

// Same calculation for every active room in one go (used by search results).
function bulkAvailability(ci, co) {
  const rooms = db.prepare('SELECT id, total_units FROM rooms WHERE active = 1').all();
  const rows = db.prepare(`SELECT room_id, check_in, check_out, rooms_count FROM bookings
    WHERE status = 'CONFIRMED' AND check_in < ? AND check_out > ?`).all(co, ci);
  const byRoom = new Map();
  for (const b of rows) {
    if (!byRoom.has(b.room_id)) byRoom.set(b.room_id, []);
    byRoom.get(b.room_id).push(b);
  }
  const out = new Map();
  for (const r of rooms) out.set(r.id, Math.max(0, r.total_units - peak(byRoom.get(r.id) || [], ci, co)));
  return out;
}

// Highest number of units of this room booked on any future night (used before lowering total_units).
function peakFutureUsage(roomId, fromDate) {
  const rows = db.prepare(`SELECT check_in, check_out, rooms_count FROM bookings
    WHERE room_id = ? AND status = 'CONFIRMED' AND check_out > ?`).all(roomId, fromDate);
  let max = 0;
  for (const r of rows) {
    const night = r.check_in > fromDate ? r.check_in : fromDate;
    let used = 0;
    for (const b of rows) if (b.check_in <= night && night < b.check_out) used += b.rooms_count;
    if (used > max) max = used;
  }
  return max;
}

module.exports = { roomAvailability, bulkAvailability, peakFutureUsage };
