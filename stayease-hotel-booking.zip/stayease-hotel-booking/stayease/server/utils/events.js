// Server-Sent Events: lets every open browser tab learn about availability changes instantly.
const clients = new Set();
function addClient(res) {
  clients.add(res);
  res.on('close', () => clients.delete(res));
}
function broadcast(event, data) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const c of clients) c.write(msg);
}
setInterval(() => { for (const c of clients) c.write(': ping\n\n'); }, 25000).unref();
module.exports = { addClient, broadcast };
