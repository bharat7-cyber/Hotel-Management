const express = require('express');
const path = require('path');
require('./db/database');
const { seedIfEmpty } = require('./db/seed');
const { attachUser } = require('./middleware/auth');
const { notFound, errorHandler } = require('./middleware/error');
const api = require('./routes');

seedIfEmpty(); // first run: creates users, hotels, rooms, bookings and reviews

const app = express();
app.disable('x-powered-by');
app.use((req, res, next) => { res.set('X-Content-Type-Options', 'nosniff'); next(); });
app.use(express.json({ limit: '100kb' }));
app.use('/api', attachUser, api, notFound);

const client = path.join(__dirname, '..', 'client');
app.use(express.static(client));
app.get('*', (req, res) => res.sendFile(path.join(client, 'index.html')));

app.use(errorHandler);
module.exports = app;
