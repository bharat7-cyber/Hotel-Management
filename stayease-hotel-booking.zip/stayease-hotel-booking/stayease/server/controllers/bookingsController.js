const db = require('../db/database');
const ApiError = require('../utils/ApiError');
const v = require('../middleware/validate');
const svc = require('../utils/bookingService');
const { validateStay } = require('../utils/dates');
const { roomAvailability } = require('../utils/availability');
const { calculatePrice, COUPONS } = require('../utils/pricing');

exports.coupons = (req, res) =>
  res.json({ coupons: Object.entries(COUPONS).map(([code, c]) => ({ code, label: c.label, minNights: c.minNights })) });

// POST /api/bookings/quote — live price + availability for the booking page (no data is saved)
exports.quote = (req, res) => {
  const room = db.prepare('SELECT * FROM rooms WHERE id = ? AND active = 1').get(v.int(req.body.roomId, 'Room', 1, 1e9));
  if (!room) throw new ApiError(404, 'Room not found');
  const nights = validateStay(req.body.checkIn, req.body.checkOut);
  const rooms = v.int(req.body.rooms, 'Rooms', 1, 9, 1);
  const available = roomAvailability(room.id, req.body.checkIn, req.body.checkOut);
  const price = calculatePrice({ pricePerNight: room.price_per_night, nights, rooms, coupon: req.body.coupon });
  res.json({ available, canBook: available >= rooms, price });
};

exports.create = (req, res) => {
  res.status(201).json({ booking: svc.createBooking(req.user.id, req.body), message: 'Booking confirmed!' });
};

exports.mine = (req, res) => {
  const rows = db.prepare(`${svc.BOOKING_SELECT} WHERE b.user_id = ? ORDER BY b.check_in DESC, b.id DESC`).all(req.user.id);
  res.json({ bookings: rows.map((r) => svc.formatBooking(r)) });
};

exports.getOne = (req, res) => {
  const b = svc.getBooking(String(req.params.ref).toUpperCase());
  if (!b || (req.user.role !== 'admin' && b.user.id !== req.user.id)) throw new ApiError(404, 'Booking not found');
  res.json({ booking: b });
};

// DELETE /api/bookings/:ref — cancels (the row is kept so history and revenue stay correct)
exports.cancel = (req, res) => {
  const booking = svc.cancelBooking(String(req.params.ref).toUpperCase(), req.user);
  res.json({ booking, message: booking.pricing.refund > 0 ? `Booking cancelled. ₹${booking.pricing.refund} will be refunded.` : 'Booking cancelled. No refund applies.' });
};
