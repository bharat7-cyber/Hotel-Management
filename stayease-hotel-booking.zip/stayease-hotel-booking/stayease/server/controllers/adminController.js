const db = require('../db/database');
const ApiError = require('../utils/ApiError');
const v = require('../middleware/validate');
const svc = require('../utils/bookingService');
const { today, addDays, nightsOf } = require('../utils/dates');
const { shapeHotel } = require('./hotelsController');

const pageOf = (q, def = 15) => {
  const page = v.int(q.page, 'Page', 1, 10000, 1);
  const limit = v.int(q.limit, 'Limit', 1, 100, def);
  return { page, limit, offset: (page - 1) * limit };
};

exports.stats = (req, res) => {
  const t = today();
  const conf = db.prepare(`SELECT COUNT(*) AS c, COALESCE(SUM(total_amount),0) AS rev FROM bookings WHERE status='CONFIRMED'`).get();
  const canc = db.prepare(`SELECT COUNT(*) AS c, COALESCE(SUM(total_amount - refund_amount),0) AS kept FROM bookings WHERE status='CANCELLED'`).get();
  const upcoming = db.prepare(`SELECT COUNT(*) AS c FROM bookings WHERE status='CONFIRMED' AND check_out > ?`).get(t).c;

  // Occupancy for the next 30 nights = occupied room-nights / available room-nights
  const end = addDays(t, 30);
  const capRows = db.prepare(`SELECT h.id, h.name, COALESCE(SUM(r.total_units),0) AS units FROM hotels h
    LEFT JOIN rooms r ON r.hotel_id = h.id AND r.active = 1 WHERE h.active = 1 GROUP BY h.id`).all();
  const occ = new Map(capRows.map((h) => [h.id, 0]));
  const bks = db.prepare(`SELECT hotel_id, check_in, check_out, rooms_count FROM bookings
    WHERE status='CONFIRMED' AND check_in < ? AND check_out > ?`).all(end, t);
  for (const b of bks) {
    const from = b.check_in > t ? b.check_in : t, to = b.check_out < end ? b.check_out : end;
    if (occ.has(b.hotel_id)) occ.set(b.hotel_id, occ.get(b.hotel_id) + nightsOf(from, to).length * b.rooms_count);
  }
  const pct = (o, u) => (u ? Math.min(100, Math.round((o / (u * 30)) * 1000) / 10) : 0);
  const byHotel = capRows.map((h) => ({ id: h.id, name: h.name, occupancy: pct(occ.get(h.id), h.units) }))
    .sort((a, b) => b.occupancy - a.occupancy);
  const totalUnits = capRows.reduce((s, h) => s + h.units, 0);
  const totalOcc = [...occ.values()].reduce((s, n) => s + n, 0);

  res.json({
    revenue: Math.round((conf.rev + canc.kept) * 100) / 100,
    totalBookings: conf.c + canc.c,
    confirmedBookings: conf.c,
    upcomingBookings: upcoming,
    cancelledBookings: canc.c,
    cancellationRate: conf.c + canc.c ? Math.round((canc.c / (conf.c + canc.c)) * 1000) / 10 : 0,
    avgBookingValue: conf.c ? Math.round(conf.rev / conf.c) : 0,
    hotels: capRows.length,
    guests: db.prepare('SELECT COUNT(*) AS c FROM guests').get().c,
    occupancy: pct(totalOcc, totalUnits),
    occupancyByHotel: byHotel.slice(0, 8),
    monthlyRevenue: db.prepare(`SELECT substr(check_in,1,7) AS month, ROUND(SUM(total_amount)) AS revenue, COUNT(*) AS bookings
      FROM bookings WHERE status='CONFIRMED' GROUP BY month ORDER BY month DESC LIMIT 6`).all().reverse(),
    topHotels: db.prepare(`SELECT h.id, h.name, COUNT(*) AS bookings, ROUND(SUM(b.total_amount)) AS revenue FROM bookings b
      JOIN hotels h ON h.id = b.hotel_id WHERE b.status='CONFIRMED' GROUP BY h.id ORDER BY revenue DESC LIMIT 5`).all(),
    recent: db.prepare(`${svc.BOOKING_SELECT} ORDER BY b.created_at DESC, b.id DESC LIMIT 6`).all().map((r) => svc.formatBooking(r, false)),
  });
};

exports.bookings = (req, res) => {
  const { page, limit, offset } = pageOf(req.query);
  let where = ' WHERE 1=1';
  const args = [];
  if (['CONFIRMED', 'CANCELLED'].includes(req.query.status)) { where += ' AND b.status = ?'; args.push(req.query.status); }
  const q = String(req.query.q || '').trim();
  if (q) {
    where += ` AND (b.booking_ref LIKE ? OR h.name LIKE ? OR u.name LIKE ? OR u.email LIKE ?
      OR EXISTS (SELECT 1 FROM guests g WHERE g.booking_id = b.id AND g.name LIKE ?))`;
    args.push(...Array(5).fill(`%${q}%`));
  }
  const total = db.prepare(`SELECT COUNT(*) AS c FROM bookings b JOIN hotels h ON h.id=b.hotel_id JOIN users u ON u.id=b.user_id ${where}`).get(...args).c;
  const rows = db.prepare(`${svc.BOOKING_SELECT} ${where} ORDER BY b.created_at DESC, b.id DESC LIMIT ? OFFSET ?`).all(...args, limit, offset);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / limit)), bookings: rows.map((r) => svc.formatBooking(r)) });
};

// PUT /api/admin/bookings/:id  { status: 'CANCELLED' | 'CONFIRMED' }
exports.updateBooking = (req, res) => {
  const id = v.int(req.params.id, 'Booking id', 1, 1e9);
  const row = db.prepare('SELECT booking_ref FROM bookings WHERE id = ?').get(id);
  if (!row) throw new ApiError(404, 'Booking not found');
  const status = String(req.body.status || '').toUpperCase();
  if (status === 'CANCELLED') return res.json({ booking: svc.cancelBooking(row.booking_ref, req.user), message: 'Booking cancelled' });
  if (status === 'CONFIRMED') return res.json({ booking: svc.reinstateBooking(id), message: 'Booking reinstated' });
  throw new ApiError(400, 'Status must be CONFIRMED or CANCELLED');
};

exports.guests = (req, res) => {
  const { page, limit, offset } = pageOf(req.query, 20);
  const q = String(req.query.q || '').trim();
  const where = q ? 'WHERE g.name LIKE ? OR g.email LIKE ? OR g.phone LIKE ? OR b.booking_ref LIKE ?' : '';
  const args = q ? Array(4).fill(`%${q}%`) : [];
  const base = `FROM guests g JOIN bookings b ON b.id = g.booking_id JOIN hotels h ON h.id = b.hotel_id ${where}`;
  const total = db.prepare(`SELECT COUNT(*) AS c ${base}`).get(...args).c;
  const rows = db.prepare(`SELECT g.id, g.name, g.email, g.phone, g.is_primary AS isPrimary, b.booking_ref AS ref, b.status,
      b.check_in AS checkIn, b.check_out AS checkOut, h.name AS hotel ${base} ORDER BY g.id DESC LIMIT ? OFFSET ?`).all(...args, limit, offset);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / limit)), guests: rows });
};

exports.hotels = (req, res) => {
  const rows = db.prepare(`SELECT h.*, (SELECT ROUND(AVG(rating),1) FROM reviews r WHERE r.hotel_id=h.id) AS rating,
      (SELECT COUNT(*) FROM reviews r WHERE r.hotel_id=h.id) AS review_count FROM hotels h ORDER BY h.active DESC, h.name`).all();
  const rooms = db.prepare('SELECT hotel_id, COUNT(*) AS n, SUM(total_units) AS units FROM rooms WHERE active=1 GROUP BY hotel_id').all();
  const map = new Map(rooms.map((r) => [r.hotel_id, r]));
  res.json({ hotels: rows.map((h) => ({ ...shapeHotel(h), roomTypes: map.get(h.id)?.n || 0, totalUnits: map.get(h.id)?.units || 0 })) });
};

exports.rooms = (req, res) => {
  const { shapeRoom } = require('./hotelsController');
  const rows = db.prepare('SELECT * FROM rooms WHERE hotel_id = ? AND active = 1 ORDER BY price_per_night').all(req.params.hotelId);
  res.json({ rooms: rows.map(shapeRoom) });
};

exports.reviews = (req, res) => {
  const rows = db.prepare(`SELECT v.id, v.rating, v.comment, v.created_at AS createdAt, u.name AS author, h.name AS hotel
    FROM reviews v JOIN users u ON u.id = v.user_id JOIN hotels h ON h.id = v.hotel_id ORDER BY v.created_at DESC LIMIT 100`).all();
  res.json({ reviews: rows });
};

exports.deleteReview = (req, res) => {
  const info = db.prepare('DELETE FROM reviews WHERE id = ?').run(req.params.id);
  if (!info.changes) throw new ApiError(404, 'Review not found');
  res.json({ message: 'Review deleted' });
};
