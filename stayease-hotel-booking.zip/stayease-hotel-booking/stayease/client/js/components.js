// The search box used on the home page, the results page and the hotel page.
import { api } from './api.js';
import { $, $$, esc, todayISO, addDays, diffDays, plural, toast } from './ui.js';

let cityCache = null;
export async function getCities() {
  if (!cityCache) cityCache = (await api('/hotels/cities')).cities;
  return cityCache;
}

const counterRow = (id, label, hint, v) => `<div class="counter"><div><b style="display:block;min-width:0;text-align:left">${label}</b><span class="muted small">${hint}</span></div>
  <div class="ctl"><button type="button" data-dec="${id}" aria-label="Fewer ${label}">−</button><b id="c-${id}">${v}</b><button type="button" data-inc="${id}" aria-label="More ${label}">+</button></div></div>`;

export function searchBoxHTML(s, { dest = true, cta = 'Search hotels' } = {}) {
  return `<form class="searchbox ${dest ? '' : 'no-dest'}" id="sb" autocomplete="off" novalidate>
    ${dest ? `<div class="sb-field sb-dest"><label for="sb-q">Where to?</label>
      <input id="sb-q" value="${esc(s.q)}" placeholder="City, state or hotel name" aria-autocomplete="list">
      <ul class="suggest" id="sb-suggest" role="listbox" hidden></ul></div>` : ''}
    <div class="sb-field"><label for="sb-in">Check-in</label><input type="date" id="sb-in" value="${s.checkIn}" min="${todayISO()}"></div>
    <div class="sb-field"><label for="sb-out">Check-out</label><input type="date" id="sb-out" value="${s.checkOut}" min="${addDays(s.checkIn, 1)}"></div>
    <div class="sb-field"><label>Guests &amp; rooms</label><button type="button" class="sb-gbtn" id="sb-g" aria-expanded="false"></button>
      <div class="gpop" id="sb-gpop" hidden>
        ${counterRow('adults', 'Adults', 'Age 13+', s.adults)}${counterRow('children', 'Children', 'Age 0–12', s.children)}${counterRow('rooms', 'Rooms', 'Max 9', s.rooms)}
        <button type="button" class="btn btn-primary btn-block btn-sm" id="sb-done" style="margin-top:8px">Done</button>
      </div></div>
    <button class="btn btn-accent sb-go" type="submit">${cta}</button>
  </form>`;
}

export function bindSearchBox(root, state, onSubmit) {
  const s = { ...state };
  const form = $('#sb', root);
  const inEl = $('#sb-in', root), outEl = $('#sb-out', root), pop = $('#sb-gpop', root), gbtn = $('#sb-g', root);
  const q = $('#sb-q', root), list = $('#sb-suggest', root);

  const label = () => { gbtn.textContent = `${plural(s.adults + s.children, 'guest')} · ${plural(s.rooms, 'room')}`; };
  const paint = () => {
    for (const k of ['adults', 'children', 'rooms']) $('#c-' + k, root).textContent = s[k];
    $('[data-dec=adults]', root).disabled = s.adults <= Math.max(1, s.rooms);
    $('[data-dec=children]', root).disabled = s.children <= 0;
    $('[data-dec=rooms]', root).disabled = s.rooms <= 1;
    $('[data-inc=adults]', root).disabled = s.adults >= 40;
    $('[data-inc=children]', root).disabled = s.children >= 20;
    $('[data-inc=rooms]', root).disabled = s.rooms >= 9;
    label();
  };
  paint();

  pop.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-inc],button[data-dec]');
    if (!b) return;
    const k = b.dataset.inc || b.dataset.dec;
    s[k] += b.dataset.inc ? 1 : -1;
    if (k === 'rooms' && s.adults < s.rooms) s.adults = s.rooms; // every room needs an adult
    paint();
  });
  const toggle = (open) => { pop.hidden = !open; gbtn.setAttribute('aria-expanded', String(open)); };
  gbtn.onclick = (e) => { e.stopPropagation(); toggle(pop.hidden); };
  $('#sb-done', root).onclick = () => toggle(false);
  const outside = (e) => {
    if (!pop.contains(e.target) && e.target !== gbtn) toggle(false);
    if (list && e.target !== q && !list.contains(e.target)) list.hidden = true;
  };
  document.addEventListener('click', outside);

  inEl.onchange = () => {
    if (!inEl.value) return;
    outEl.min = addDays(inEl.value, 1);
    if (!outEl.value || diffDays(inEl.value, outEl.value) < 1) outEl.value = addDays(inEl.value, 1);
    outEl.focus(); outEl.showPicker?.();
  };

  if (q) {
    const show = async () => {
      const text = q.value.trim().toLowerCase();
      let cities = [];
      try { cities = await getCities(); } catch { return; }
      const hits = cities.filter((c) => !text || c.city.toLowerCase().includes(text) || c.state.toLowerCase().includes(text)).slice(0, 7);
      list.innerHTML = hits.length
        ? hits.map((c) => `<li role="option" data-v="${esc(c.city)}"><span>📍 <b>${esc(c.city)}</b>, ${esc(c.state)}</span><span class="muted small">${plural(c.hotels, 'hotel')}</span></li>`).join('')
        : `<li class="muted" style="cursor:default">No match, we'll search hotel names and areas too</li>`;
      list.hidden = false;
    };
    q.addEventListener('focus', show);
    q.addEventListener('input', show);
    list.addEventListener('mousedown', (e) => {
      const li = e.target.closest('li[data-v]');
      if (li) { q.value = li.dataset.v; list.hidden = true; inEl.focus(); }
    });
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!inEl.value || !outEl.value) return toast('Please choose your check-in and check-out dates', 'error');
    if (inEl.value < todayISO()) return toast('Check-in cannot be in the past', 'error');
    if (diffDays(inEl.value, outEl.value) < 1) return toast('Check-out must be after check-in', 'error');
    if (diffDays(inEl.value, outEl.value) > 30) return toast('You can book up to 30 nights at a time', 'error');
    onSubmit({ q: q ? q.value.trim() : state.q, checkIn: inEl.value, checkOut: outEl.value, adults: s.adults, children: s.children, rooms: s.rooms });
  });
  return () => document.removeEventListener('click', outside);
}

// ---------- Shared booking pieces (confirmation page, My bookings, admin) ----------
import { money, fmtDate, fmtDateTime, confirmDialog, toast as notify } from './ui.js';

export const statusBadge = (b) => ({
  upcoming: '<span class="badge b-ok">Upcoming</span>', ongoing: '<span class="badge b-info">Staying now</span>',
  past: '<span class="badge b-info">Completed</span>', cancelled: '<span class="badge b-bad">Cancelled</span>',
}[b.phase]);

export function bookingDetailsHTML(b) {
  const p = b.pricing;
  return `<div class="grid2" style="margin-top:10px">
    <div><p class="muted small" style="margin:0">Hotel</p><b>${esc(b.hotel.name)}</b><br><span class="muted small">${esc(b.hotel.address)}, ${esc(b.hotel.city)}</span></div>
    <div><p class="muted small" style="margin:0">Room</p><b>${esc(b.room.name)}</b> × ${b.rooms}<br><span class="muted small">${plural(b.adults, 'adult')}${b.children ? ', ' + plural(b.children, 'child', 'children') : ''}</span></div>
    <div><p class="muted small" style="margin:0">Check-in</p><b>${fmtDate(b.checkIn)}</b><br><span class="muted small">from 2:00 PM</span></div>
    <div><p class="muted small" style="margin:0">Check-out</p><b>${fmtDate(b.checkOut)}</b><br><span class="muted small">until 11:00 AM · ${plural(b.nights, 'night')}</span></div>
  </div>
  <h4 style="margin:18px 0 6px">Guests</h4>
  <div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th></tr></thead><tbody>
    ${b.guests.map((g) => `<tr><td>${esc(g.name)} ${g.isPrimary ? '<span class="badge b-info">Primary</span>' : ''}</td><td>${esc(g.email || '–')}</td><td>${esc(g.phone || '–')}</td></tr>`).join('')}
  </tbody></table></div>
  ${b.specialRequests ? `<p style="margin-top:12px"><b>Special requests:</b> ${esc(b.specialRequests)}</p>` : ''}
  <h4 style="margin:18px 0 4px">Payment summary <span class="muted small">(pay at the hotel)</span></h4>
  <div class="sum-row"><span>Room charges (${plural(b.nights, 'night')} × ${plural(b.rooms, 'room')})</span><span>${money(p.base)}</span></div>
  ${p.discount ? `<div class="sum-row"><span>Discounts${p.coupon ? ' (incl. ' + esc(p.coupon) + ')' : ''}</span><span class="neg">−${money(p.discount)}</span></div>` : ''}
  <div class="sum-row"><span>Taxes (GST)</span><span>${money(p.tax)}</span></div>
  <div class="sum-row total"><span>Total</span><span>${money(p.total)}</span></div>
  ${b.status === 'CANCELLED' ? `<div class="notice n-warn">Cancelled ${b.cancelledAt ? fmtDateTime(b.cancelledAt) : ''}. Refund: <b>${money(p.refund)}</b>.</div>` : ''}
  <p class="muted small">Booked on ${fmtDateTime(b.createdAt)}</p>`;
}

// Asks for confirmation, shows the refund the guest will get, then cancels through the API.
export async function cancelFlow(b, after, { admin = false } = {}) {
  const refund = admin ? b.pricing.total : b.refundPreview;
  const ok = await confirmDialog({
    title: `Cancel booking ${b.ref}?`, danger: true, confirmText: 'Yes, cancel booking', cancelText: 'Keep booking',
    message: `${esc(b.hotel.name)}, ${fmtDate(b.checkIn, { day: 'numeric', month: 'short' })} to ${fmtDate(b.checkOut, { day: 'numeric', month: 'short' })}.<br><br>` +
      (refund > 0 ? `You will be refunded <b>${money(refund)}</b>${admin ? '' : ` (${b.refundPercent}% of the total)`}.` : 'This is inside the free-cancellation window, so <b>no refund</b> applies.') + '<br>This cannot be undone.',
  });
  if (!ok) return false;
  try {
    const r = admin
      ? await api(`/admin/bookings/${b.id}`, { method: 'PUT', body: { status: 'CANCELLED' } })
      : await api(`/bookings/${b.ref}`, { method: 'DELETE' });
    notify(r.message || 'Booking cancelled', 'success');
    after?.(r.booking);
    return true;
  } catch (e) { notify(e.message, 'error'); return false; }
}
