// Remembers the guest's search (destination, dates, party) while they browse.
import { todayISO, addDays, diffDays } from './ui.js';
const KEY = 'stayease_search';

const defaults = () => ({ q: '', checkIn: addDays(todayISO(), 1), checkOut: addDays(todayISO(), 2), adults: 2, children: 0, rooms: 1 });

function clean(s) {
  const t = todayISO();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s.checkIn || '') || s.checkIn < t) s.checkIn = addDays(t, 1);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s.checkOut || '') || diffDays(s.checkIn, s.checkOut) < 1) s.checkOut = addDays(s.checkIn, 1);
  if (diffDays(s.checkIn, s.checkOut) > 30) s.checkOut = addDays(s.checkIn, 30);
  s.adults = Math.min(40, Math.max(1, Number(s.adults) || 1));
  s.children = Math.min(20, Math.max(0, Number(s.children) || 0));
  s.rooms = Math.min(9, Math.max(1, Number(s.rooms) || 1));
  if (s.adults < s.rooms) s.adults = s.rooms;
  return s;
}
export function getSearch() {
  let saved = {};
  try { saved = JSON.parse(sessionStorage.getItem(KEY)) || {}; } catch { /* ignore */ }
  return clean({ ...defaults(), ...saved });
}
export function setSearch(patch) {
  const s = clean({ ...getSearch(), ...patch });
  sessionStorage.setItem(KEY, JSON.stringify(s));
  return s;
}
// Reads search fields from a URL query (so links are shareable) and saves them.
export function searchFromParams(p) {
  const patch = {};
  for (const k of ['q', 'checkIn', 'checkOut', 'adults', 'children', 'rooms']) if (p.has(k)) patch[k] = p.get(k);
  return setSearch(patch);
}
export const searchParams = (s) => ({ checkIn: s.checkIn, checkOut: s.checkOut, adults: s.adults, children: s.children, rooms: s.rooms });
