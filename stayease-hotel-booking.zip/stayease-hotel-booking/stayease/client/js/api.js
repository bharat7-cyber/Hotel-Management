// Thin wrapper around fetch(): adds the login token, parses JSON and turns failures into readable errors.
const TOKEN_KEY = 'stayease_token';
export const token = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

export async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token.get()) headers.Authorization = 'Bearer ' + token.get();
  let res;
  try {
    res = await fetch('/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    const e = new Error('Cannot reach the server. Check your connection and try again.');
    e.status = 0;
    throw e;
  }
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    if (res.status === 401 && token.get() && !path.startsWith('/auth/')) {
      token.clear();
      window.dispatchEvent(new CustomEvent('session-expired'));
    }
    const e = new Error(data.error || `Request failed (${res.status})`);
    e.status = res.status;
    throw e;
  }
  return data;
}
export const qs = (obj) =>
  new URLSearchParams(Object.entries(obj).filter(([, v]) => v !== '' && v != null && v !== false)).toString();
