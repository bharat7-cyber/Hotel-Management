// Admin area: dashboard, hotels + rooms CRUD, bookings, guests, reviews. Every table reads from and writes to the API.
import { api, qs } from '../api.js';
import { $, $$, esc, money, plural, toast, openModal, closeModal, confirmDialog, busy, fmtDate, skeletonCards, emptyState, errorState, debounce, AMENITY, img, stars } from '../ui.js';
import { session, isAdmin } from '../session.js';
import { showAuth } from '../auth.js';
import { bus } from '../bus.js';
import { bookingDetailsHTML, cancelFlow, statusBadge } from '../components.js';

const TABS = [['dashboard', '📊 Dashboard'], ['hotels', '🏨 Hotels & rooms'], ['bookings', '🧾 Bookings'], ['guests', '👥 Guests'], ['reviews', '⭐ Reviews']];

export async function render(root, { args }) {
  if (!session.user) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🔐</div><h2>Admin login required</h2><button class="btn btn-primary" id="li">Log in</button></div></div>`;
    $('#li', root).onclick = () => showAuth('login');
    showAuth('login', 'Use the admin account to open the dashboard.');
    return;
  }
  if (!isAdmin()) {
    root.innerHTML = `<div class="container page-pad"><div class="empty"><div class="big">🚫</div><h2>Admins only</h2><p class="muted">Your account does not have access to this area.</p><a class="btn btn-primary" href="#/">Go home</a></div></div>`;
    return;
  }
  const tab = TABS.some(([k]) => k === args[0]) ? args[0] : 'dashboard';
  root.innerHTML = `<div class="container admin">
    <nav class="side" aria-label="Admin">${TABS.map(([k, l]) => `<a href="#/admin/${k}" class="${k === tab ? 'on' : ''}">${l}</a>`).join('')}</nav>
    <section id="main" class="fade-in"></section></div>`;
  const main = $('#main', root);
  main.innerHTML = skeletonCards(3, 120);
  const off = await ({ dashboard, hotels, bookings, guests, reviews })[tab](main);
  return off;
}

const pager = (d, go) => `<div class="pager"><button class="btn btn-ghost btn-sm" data-p="${d.page - 1}" ${d.page <= 1 ? 'disabled' : ''}>← Prev</button>
  <span class="muted small">Page ${d.page} of ${d.pages} · ${d.total} total</span><button class="btn btn-ghost btn-sm" data-p="${d.page + 1}" ${d.page >= d.pages ? 'disabled' : ''}>Next →</button></div>`;
const bindPager = (el, go) => $$('[data-p]', el).forEach((b) => (b.onclick = () => go(Number(b.dataset.p))));
const fail = (el, e, retry) => { el.innerHTML = errorState(e.message); $('[data-retry]', el).onclick = retry; };

// ---------------- Dashboard ----------------
async function dashboard(main) {
  async function load() {
    try {
      const s = await api('/admin/stats');
      const maxRev = Math.max(1, ...s.monthlyRevenue.map((m) => m.revenue));
      const month = (m) => new Date(m + '-01T00:00:00Z').toLocaleDateString('en-IN', { month: 'short', year: '2-digit', timeZone: 'UTC' });
      main.innerHTML = `<h1 style="font-size:1.8rem">Dashboard</h1>
        <div class="kpis">
          <div class="kpi"><small>Revenue</small><b>${money(s.revenue)}</b></div>
          <div class="kpi"><small>Bookings</small><b>${s.totalBookings}</b><span class="muted small">${s.confirmedBookings} confirmed · ${s.cancelledBookings} cancelled</span></div>
          <div class="kpi"><small>Upcoming stays</small><b>${s.upcomingBookings}</b></div>
          <div class="kpi"><small>Occupancy (next 30 days)</small><b>${s.occupancy}%</b></div>
          <div class="kpi"><small>Avg. booking value</small><b>${money(s.avgBookingValue)}</b></div>
          <div class="kpi"><small>Cancellation rate</small><b>${s.cancellationRate}%</b></div>
          <div class="kpi"><small>Hotels</small><b>${s.hotels}</b></div>
          <div class="kpi"><small>Guests on file</small><b>${s.guests}</b></div>
        </div>
        <div class="twocol">
          <div class="panel"><h3>Revenue by check-in month</h3><div class="chart">${s.monthlyRevenue.map((m) => `<div class="col"><span>${money(m.revenue)}</span><div class="bar" style="height:${Math.max(3, (m.revenue / maxRev) * 130)}px" title="${m.bookings} bookings"></div><b>${month(m.month)}</b></div>`).join('') || '<p class="muted">No revenue yet.</p>'}</div></div>
          <div class="panel"><h3>Occupancy by hotel <span class="muted small">(next 30 days)</span></h3>${s.occupancyByHotel.map((h) => `<div class="hb"><span>${esc(h.name)}</span><div class="track"><i style="width:${h.occupancy}%"></i></div><b>${h.occupancy}%</b></div>`).join('')}</div>
        </div>
        <div class="twocol">
          <div class="panel"><h3>Top hotels by revenue</h3><div class="table-wrap" style="border:0"><table><thead><tr><th>Hotel</th><th>Bookings</th><th>Revenue</th></tr></thead><tbody>
            ${s.topHotels.map((h) => `<tr><td>${esc(h.name)}</td><td>${h.bookings}</td><td>${money(h.revenue)}</td></tr>`).join('')}</tbody></table></div></div>
          <div class="panel"><h3>Latest bookings</h3><div class="table-wrap" style="border:0"><table><thead><tr><th>ID</th><th>Guest</th><th>Total</th></tr></thead><tbody>
            ${s.recent.map((b) => `<tr><td><b>${esc(b.ref)}</b><br><span class="muted small">${esc(b.hotel.name)}</span></td><td>${esc(b.user.name)}</td><td>${money(b.pricing.total)}<br>${statusBadge(b)}</td></tr>`).join('')}</tbody></table></div>
            <a href="#/admin/bookings">Manage all bookings →</a></div>
        </div>`;
    } catch (e) { fail(main, e, load); }
  }
  await load();
  return bus.on('availability', debounce(load, 800)); // dashboard updates itself when bookings change
}

// ---------------- generic form dialog ----------------
function formModal({ title, fields, values = {}, submitText = 'Save', onSubmit, back }) {
  const control = (f) => {
    const v = values[f.name] ?? f.default ?? '';
    const attrs = `id="f-${f.name}" ${f.min != null ? `min="${f.min}"` : ''} ${f.max != null ? `max="${f.max}"` : ''} ${f.step ? `step="${f.step}"` : ''} ${f.placeholder ? `placeholder="${esc(f.placeholder)}"` : ''}`;
    if (f.type === 'textarea') return `<textarea ${attrs}>${esc(f.list ? (v || []).join('\n') : v)}</textarea>`;
    if (f.type === 'select') return `<select ${attrs}>${f.options.map(([val, l]) => `<option value="${val}" ${String(v) === String(val) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    if (f.type === 'checkbox') return `<label class="check"><input type="checkbox" id="f-${f.name}" ${v ? 'checked' : ''}> ${esc(f.label)}</label>`;
    if (f.type === 'amenities') return `<div class="checks">${Object.entries(AMENITY).map(([k, [ic, l]]) => `<label class="check"><input type="checkbox" data-am="${k}" ${(v || []).includes(k) ? 'checked' : ''}> ${ic} ${l}</label>`).join('')}</div>`;
    return `<input ${attrs} type="${f.type || 'text'}" value="${esc(v)}">`;
  };
  const m = openModal(`<h3>${esc(title)}</h3><form id="gf" novalidate><div class="grid2">
    ${fields.map((f) => `<div class="field" ${f.full ? 'style="grid-column:1/-1"' : ''}>${f.type === 'checkbox' ? '' : `<label for="f-${f.name}">${esc(f.label)}${f.required ? ' *' : ''}</label>`}${control(f)}${f.hint ? `<div class="muted small">${esc(f.hint)}</div>` : ''}<div class="err" hidden></div></div>`).join('')}
    </div><div class="notice n-bad" id="gf-err" hidden></div>
    <div style="display:flex;justify-content:flex-end;gap:10px"><button type="button" class="btn btn-ghost" id="gf-cancel">Cancel</button><button class="btn btn-primary" type="submit">${esc(submitText)}</button></div></form>`, { wide: true });
  $('#gf-cancel', m).onclick = () => (back ? back() : closeModal());
  $('#gf', m).addEventListener('submit', async (e) => {
    e.preventDefault();
    const out = {}; let ok = true;
    $$('.invalid', m).forEach((x) => x.classList.remove('invalid'));
    $$('.field .err', m).forEach((x) => (x.hidden = true));
    for (const f of fields) {
      const el = $('#f-' + f.name, m);
      if (f.type === 'checkbox') out[f.name] = el.checked;
      else if (f.type === 'amenities') out[f.name] = $$('[data-am]:checked', m).map((c) => c.dataset.am);
      else if (f.list) out[f.name] = el.value.split('\n').map((x) => x.trim()).filter(Boolean);
      else out[f.name] = f.type === 'number' ? el.value : el.value.trim();
      if (f.required && (out[f.name] === '' || out[f.name] == null)) {
        el.classList.add('invalid'); const er = el.closest('.field').querySelector('.err'); er.textContent = `${f.label} is required`; er.hidden = false; ok = false;
      }
    }
    if (!ok) return;
    await busy($('button[type=submit]', m), async () => {
      try { await onSubmit(out); }
      catch (ex) { const er = $('#gf-err', m); er.textContent = ex.message; er.hidden = false; }
    });
  });
}

// ---------------- Hotels & rooms ----------------
const HOTEL_FIELDS = [
  { name: 'name', label: 'Hotel name', required: true }, { name: 'city', label: 'City', required: true },
  { name: 'state', label: 'State' }, { name: 'stars', label: 'Star rating', type: 'select', options: [5, 4, 3, 2, 1].map((n) => [n, '★'.repeat(n)]), default: 3 },
  { name: 'address', label: 'Address', full: true }, { name: 'description', label: 'Description', type: 'textarea', full: true },
  { name: 'image', label: 'Main image URL', type: 'url', full: true, placeholder: 'https://…' },
  { name: 'gallery', label: 'Gallery image URLs', type: 'textarea', list: true, full: true, hint: 'One URL per line (up to 8)' },
  { name: 'amenities', label: 'Amenities', type: 'amenities', full: true }, { name: 'active', label: 'Visible to guests', type: 'checkbox', default: true },
];
const ROOM_FIELDS = [
  { name: 'name', label: 'Room name', required: true },
  { name: 'type', label: 'Type', type: 'select', options: [['standard', 'Standard'], ['deluxe', 'Deluxe'], ['suite', 'Suite'], ['family', 'Family']] },
  { name: 'pricePerNight', label: 'Price per night (₹)', type: 'number', min: 1, required: true },
  { name: 'capacity', label: 'Guests per room', type: 'number', min: 1, max: 10, required: true },
  { name: 'totalUnits', label: 'Number of rooms of this type', type: 'number', min: 1, required: true },
  { name: 'sizeSqm', label: 'Size (m²)', type: 'number', min: 5 }, { name: 'beds', label: 'Beds', full: true, placeholder: '1 King bed' },
  { name: 'image', label: 'Image URL', type: 'url', full: true }, { name: 'amenities', label: 'Room amenities', type: 'amenities', full: true },
];

async function hotels(main) {
  let list = [], filter = '';
  const paint = () => {
    const rows = list.filter((h) => `${h.name} ${h.city}`.toLowerCase().includes(filter));
    $('#tbl', main).innerHTML = rows.length ? `<div class="table-wrap"><table><thead><tr><th>Hotel</th><th>City</th><th>Stars</th><th>Rooms</th><th>Rating</th><th>Status</th><th></th></tr></thead><tbody>
      ${rows.map((h) => `<tr data-id="${h.id}"><td><b>${esc(h.name)}</b></td><td>${esc(h.city)}</td><td>${h.stars}★</td><td>${h.roomTypes} types · ${h.totalUnits} rooms</td><td>${h.rating ? h.rating.toFixed(1) + ' (' + h.reviewCount + ')' : '–'}</td>
        <td>${h.active ? '<span class="badge b-ok">Live</span>' : '<span class="badge b-bad">Hidden</span>'}</td>
        <td style="white-space:nowrap"><button class="btn btn-ghost btn-sm" data-a="rooms">Rooms</button> <button class="btn btn-ghost btn-sm" data-a="edit">Edit</button> <button class="btn btn-danger btn-sm" data-a="del">Delete</button></td></tr>`).join('')}
      </tbody></table></div>` : emptyState('🏨', 'No hotels found', 'Try a different search or add a hotel.');
    $$('tr[data-id]', main).forEach((tr) => {
      const h = list.find((x) => x.id === Number(tr.dataset.id));
      $('[data-a=edit]', tr).onclick = () => hotelForm(h);
      $('[data-a=rooms]', tr).onclick = () => roomsModal(h);
      $('[data-a=del]', tr).onclick = async () => {
        if (!(await confirmDialog({ title: `Delete ${h.name}?`, message: 'Hotels with booking history are hidden instead of deleted. Hotels with upcoming bookings cannot be removed.', confirmText: 'Delete hotel', cancelText: 'Cancel', danger: true }))) return;
        try { const r = await api('/hotels/' + h.id, { method: 'DELETE' }); toast(r.message, 'success'); load(); } catch (e) { toast(e.message, 'error', 5000); }
      };
    });
  };
  function hotelForm(h) {
    formModal({
      title: h ? `Edit ${h.name}` : 'Add hotel', fields: HOTEL_FIELDS, values: h || {}, submitText: h ? 'Save changes' : 'Create hotel',
      onSubmit: async (v) => {
        await api(h ? '/hotels/' + h.id : '/hotels', { method: h ? 'PUT' : 'POST', body: v });
        closeModal(); toast(h ? 'Hotel updated' : 'Hotel created. Now add its rooms.', 'success'); load();
      },
    });
  }
  async function roomsModal(h) {
    const m = openModal(`<h3>${esc(h.name)} · Rooms</h3><div id="rm">${skeletonCards(2, 60)}</div>`, { wide: true });
    try {
      const { rooms } = await api(`/admin/hotels/${h.id}/rooms`);
      $('#rm', m).innerHTML = `<div style="display:flex;justify-content:space-between;margin-bottom:10px"><span class="muted">${plural(rooms.length, 'room type')}</span><button class="btn btn-primary btn-sm" id="add-room">+ Add room type</button></div>
        ${rooms.length ? `<div class="table-wrap"><table><thead><tr><th>Room</th><th>Price / night</th><th>Sleeps</th><th>Units</th><th></th></tr></thead><tbody>
        ${rooms.map((r) => `<tr data-r="${r.id}"><td><b>${esc(r.name)}</b><br><span class="muted small">${esc(r.type)} · ${esc(r.beds)}</span></td><td>${money(r.pricePerNight)}</td><td>${r.capacity}</td><td>${r.totalUnits}</td>
          <td style="white-space:nowrap"><button class="btn btn-ghost btn-sm" data-a="edit">Edit</button> <button class="btn btn-danger btn-sm" data-a="del">Delete</button></td></tr>`).join('')}</tbody></table></div>`
        : emptyState('🛏️', 'No rooms yet', 'Guests cannot book this hotel until you add a room type.')}`;
      $('#add-room', m).onclick = () => roomForm(h, null);
      $$('tr[data-r]', m).forEach((tr) => {
        const r = rooms.find((x) => x.id === Number(tr.dataset.r));
        $('[data-a=edit]', tr).onclick = () => roomForm(h, r);
        $('[data-a=del]', tr).onclick = async () => {
          try { const res = await api('/rooms/' + r.id, { method: 'DELETE' }); toast(res.message, 'success'); roomsModal(h); load(); }
          catch (e) { toast(e.message, 'error', 5000); }
        };
      });
    } catch (e) { $('#rm', m).innerHTML = `<div class="notice n-bad">${esc(e.message)}</div>`; }
  }
  function roomForm(h, r) {
    formModal({
      title: r ? `Edit ${r.name}` : `New room type at ${h.name}`, fields: ROOM_FIELDS, values: r || { capacity: 2, totalUnits: 5, sizeSqm: 24 },
      submitText: r ? 'Save room' : 'Add room', back: () => roomsModal(h),
      onSubmit: async (v) => {
        await api(r ? '/rooms/' + r.id : `/hotels/${h.id}/rooms`, { method: r ? 'PUT' : 'POST', body: v });
        toast(r ? 'Room updated' : 'Room added', 'success'); roomsModal(h); load();
      },
    });
  }
  async function load() {
    try { list = (await api('/admin/hotels')).hotels; paint(); } catch (e) { fail($('#tbl', main), e, load); }
  }
  main.innerHTML = `<h1 style="font-size:1.8rem">Hotels &amp; rooms</h1>
    <div class="toolbar"><input id="q" class="grow" placeholder="Search by hotel or city" aria-label="Search hotels"><button class="btn btn-primary" id="add">+ Add hotel</button></div><div id="tbl">${skeletonCards(3, 60)}</div>`;
  $('#q', main).oninput = (e) => { filter = e.target.value.trim().toLowerCase(); paint(); };
  $('#add', main).onclick = () => hotelForm(null);
  await load();
}

// ---------------- Bookings ----------------
async function bookings(main) {
  const f = { q: '', status: '', page: 1 };
  main.innerHTML = `<h1 style="font-size:1.8rem">Bookings</h1>
    <div class="toolbar"><input id="q" class="grow" placeholder="Search by booking ID, guest, email or hotel" aria-label="Search bookings">
      <select id="st" aria-label="Status"><option value="">All statuses</option><option value="CONFIRMED">Confirmed</option><option value="CANCELLED">Cancelled</option></select></div><div id="tbl"></div>`;
  async function load() {
    const box = $('#tbl', main);
    try {
      const d = await api('/admin/bookings?' + qs({ q: f.q, status: f.status, page: f.page }));
      box.innerHTML = d.bookings.length ? `<div class="table-wrap"><table><thead><tr><th>Booking</th><th>Guest</th><th>Hotel / room</th><th>Stay</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>
        ${d.bookings.map((b) => `<tr data-ref="${b.ref}"><td><b>${esc(b.ref)}</b></td><td>${esc(b.guests[0]?.name || b.user.name)}<br><span class="muted small">${esc(b.guests[0]?.phone || '')}</span></td>
          <td>${esc(b.hotel.name)}<br><span class="muted small">${esc(b.room.name)} × ${b.rooms}</span></td>
          <td style="white-space:nowrap">${fmtDate(b.checkIn, { day: 'numeric', month: 'short' })} → ${fmtDate(b.checkOut, { day: 'numeric', month: 'short', year: '2-digit' })}<br><span class="muted small">${plural(b.nights, 'night')}</span></td>
          <td>${money(b.pricing.total)}</td><td>${statusBadge(b)}</td>
          <td style="white-space:nowrap"><button class="btn btn-ghost btn-sm" data-a="view">View</button>
          ${b.status === 'CONFIRMED' && b.phase !== 'past' && b.phase !== 'ongoing' ? '<button class="btn btn-danger btn-sm" data-a="cancel">Cancel</button>' : ''}
          ${b.status === 'CANCELLED' && b.checkIn >= new Date().toISOString().slice(0, 10) ? '<button class="btn btn-primary btn-sm" data-a="reinstate">Reinstate</button>' : ''}</td></tr>`).join('')}</tbody></table></div>${pager(d)}`
        : emptyState('🧾', 'No bookings match', 'Try a different search or status.');
      bindPager(box, (p) => { f.page = p; load(); });
      $$('tr[data-ref]', box).forEach((tr) => {
        const b = d.bookings.find((x) => x.ref === tr.dataset.ref);
        $('[data-a=view]', tr).onclick = () => openModal(`<h3>Booking ${esc(b.ref)} ${statusBadge(b)}</h3><p class="muted small">Booked by ${esc(b.user.name)} (${esc(b.user.email)})</p>${bookingDetailsHTML(b)}`, { wide: true });
        $('[data-a=cancel]', tr)?.addEventListener('click', () => cancelFlow(b, load, { admin: true }));
        $('[data-a=reinstate]', tr)?.addEventListener('click', async (e) => busy(e.currentTarget, async () => {
          try { await api(`/admin/bookings/${b.id}`, { method: 'PUT', body: { status: 'CONFIRMED' } }); toast('Booking reinstated', 'success'); load(); }
          catch (ex) { toast(ex.message, 'error', 5000); }
        }));
      });
    } catch (e) { fail(box, e, load); }
  }
  $('#q', main).oninput = debounce((e) => { f.q = e.target.value.trim(); f.page = 1; load(); });
  $('#st', main).onchange = (e) => { f.status = e.target.value; f.page = 1; load(); };
  await load();
  return bus.on('availability', debounce(load, 800));
}

// ---------------- Guests ----------------
async function guests(main) {
  const f = { q: '', page: 1 };
  main.innerHTML = `<h1 style="font-size:1.8rem">Guests</h1><div class="toolbar"><input id="q" class="grow" placeholder="Search by name, email, phone or booking ID" aria-label="Search guests"></div><div id="tbl"></div>`;
  async function load() {
    const box = $('#tbl', main);
    try {
      const d = await api('/admin/guests?' + qs({ q: f.q, page: f.page, limit: 15 }));
      box.innerHTML = d.guests.length ? `<div class="table-wrap"><table><thead><tr><th>Guest</th><th>Contact</th><th>Hotel</th><th>Stay</th><th>Booking</th></tr></thead><tbody>
        ${d.guests.map((g) => `<tr><td><b>${esc(g.name)}</b> ${g.isPrimary ? '<span class="badge b-info">Primary</span>' : ''}</td><td>${esc(g.email || '–')}<br><span class="muted small">${esc(g.phone || '')}</span></td><td>${esc(g.hotel)}</td>
          <td style="white-space:nowrap">${fmtDate(g.checkIn, { day: 'numeric', month: 'short' })} → ${fmtDate(g.checkOut, { day: 'numeric', month: 'short', year: '2-digit' })}</td>
          <td>${esc(g.ref)} ${g.status === 'CANCELLED' ? '<span class="badge b-bad">Cancelled</span>' : ''}</td></tr>`).join('')}</tbody></table></div>${pager(d)}`
        : emptyState('👥', 'No guests found', 'Guests appear here after a booking is made.');
      bindPager(box, (p) => { f.page = p; load(); });
    } catch (e) { fail(box, e, load); }
  }
  $('#q', main).oninput = debounce((e) => { f.q = e.target.value.trim(); f.page = 1; load(); });
  await load();
}

// ---------------- Reviews ----------------
async function reviews(main) {
  main.innerHTML = `<h1 style="font-size:1.8rem">Reviews</h1><div id="tbl"></div>`;
  async function load() {
    const box = $('#tbl', main);
    try {
      const { reviews: list } = await api('/admin/reviews');
      box.innerHTML = list.length ? `<div class="table-wrap"><table><thead><tr><th>Hotel</th><th>Guest</th><th>Rating</th><th>Comment</th><th></th></tr></thead><tbody>
        ${list.map((r) => `<tr data-id="${r.id}"><td>${esc(r.hotel)}</td><td>${esc(r.author)}</td><td class="stars">${'★'.repeat(r.rating)}</td><td style="max-width:380px">${esc(r.comment)}</td><td><button class="btn btn-danger btn-sm" data-a="del">Delete</button></td></tr>`).join('')}</tbody></table></div>`
        : emptyState('⭐', 'No reviews yet', 'Reviews from guests will show up here.');
      $$('tr[data-id]', box).forEach((tr) => ($('[data-a=del]', tr).onclick = async () => {
        if (!(await confirmDialog({ title: 'Delete this review?', message: 'It will disappear from the hotel page and the hotel rating will be recalculated.', confirmText: 'Delete review', cancelText: 'Cancel', danger: true }))) return;
        try { await api('/admin/reviews/' + tr.dataset.id, { method: 'DELETE' }); toast('Review deleted', 'success'); load(); } catch (e) { toast(e.message, 'error'); }
      }));
    } catch (e) { fail(box, e, load); }
  }
  await load();
}
