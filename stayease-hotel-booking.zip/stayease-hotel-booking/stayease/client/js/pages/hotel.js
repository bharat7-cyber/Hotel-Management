import { api, qs } from '../api.js';
import { $, $$, esc, money, img, plural, stars, ratingBadge, amenityChips, AMENITY, skeletonCards, errorState, fmtDate, toast, debounce, fmtDate as fd } from '../ui.js';
import { searchFromParams, setSearch } from '../state.js';
import { searchBoxHTML, bindSearchBox } from '../components.js';
import { bus } from '../bus.js';

export async function render(root, { params, args }) {
  const id = args[0];
  let s = searchFromParams(params);
  root.innerHTML = `<div class="container page-pad"><div class="skel" style="height:360px"></div><div class="skel" style="height:200px;margin-top:20px"></div></div>`;

  const fetchHotel = () => api(`/hotels/${id}?` + qs({ checkIn: s.checkIn, checkOut: s.checkOut, rooms: s.rooms, guests: s.adults + s.children }));
  let data = await fetchHotel();
  const h = data.hotel;
  const pics = [...new Set([h.image, ...h.gallery].filter(Boolean))];
  const bookQs = (r) => qs({ roomId: r.id, checkIn: s.checkIn, checkOut: s.checkOut, rooms: s.rooms, adults: s.adults, children: s.children });

  root.innerHTML = `<div class="container page-pad fade-in">
    <p class="crumbs"><a href="#/">Home</a> › <a href="#/hotels?${qs({ q: h.city, checkIn: s.checkIn, checkOut: s.checkOut, adults: s.adults, children: s.children, rooms: s.rooms })}">${esc(h.city)}</a> › ${esc(h.name)}</p>
    <div style="display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;align-items:flex-start">
      <div><h1 style="font-size:clamp(1.7rem,3.4vw,2.4rem);margin-bottom:4px">${esc(h.name)}</h1>${stars(h.stars)}
        <p class="loc">📍 ${esc(h.address)}${h.address ? ', ' : ''}${esc(h.city)}, ${esc(h.state)}</p></div>
      <div id="rating">${ratingBadge(data.hotel.rating, data.hotel.reviewCount)}</div>
    </div>
    <div class="gallery"><div class="main" id="main-pic">${img(pics[0], h.name)}</div>
      <div class="thumbs">${pics.slice(0, 4).map((p, i) => `<button class="${i === 0 ? 'on' : ''}" data-pic="${esc(p)}" aria-label="Show photo ${i + 1}">${img(p, h.name + ' photo ' + (i + 1))}</button>`).join('')}</div></div>
    <div class="panel" style="padding:10px;margin-bottom:22px;background:var(--brand-d)">${searchBoxHTML(s, { dest: false, cta: 'Check availability' })}</div>
    <div class="two">
      <div>
        <section class="panel" style="margin-bottom:22px"><h2>About this hotel</h2><p>${esc(h.description)}</p>
          <h3 style="margin-top:18px">Amenities</h3><div class="amen">${h.amenities.map((a) => `<div>${AMENITY[a]?.[0] || '•'} ${esc(AMENITY[a]?.[1] || a)}</div>`).join('')}</div></section>
        <section id="rooms-sec"><div style="display:flex;justify-content:space-between;align-items:end;flex-wrap:wrap;gap:6px"><h2>Choose your room</h2><span class="muted small" id="rooms-sub"></span></div>
          <div id="rooms"></div></section>
        <section class="panel" style="margin-top:22px"><h2>Guest reviews</h2><div id="reviews"></div></section>
      </div>
      <aside class="sticky"><div class="panel">
        <h3>Good to know</h3>
        <p>🕑 Check-in from 2:00 PM, check-out until 11:00 AM</p>
        <p>↩️ Free cancellation up to 2 days before check-in. 50% refund one day before.</p>
        <p>💳 Pay at the hotel. No card needed to book.</p>
        <p>🏷️ Use <b>WELCOME10</b> for 10% off.</p>
        <div id="live" class="notice n-ok small" style="margin-bottom:0">⚡ Availability updates live while you browse.</div>
      </div></aside>
    </div></div>`;

  $$('[data-pic]', root).forEach((b) => (b.onclick = () => {
    $('#main-pic img', root).src = b.dataset.pic;
    $$('[data-pic]', root).forEach((x) => x.classList.toggle('on', x === b));
  }));

  const roomHTML = (r) => {
    const sold = r.available === 0, left = r.available;
    const q = r.quote;
    const badge = sold ? '<span class="badge b-bad">Sold out</span>' : left <= 3 ? `<span class="badge b-warn">Only ${left} left</span>` : '<span class="badge b-ok">Available</span>';
    let cta;
    if (sold) cta = '<button class="btn btn-ghost btn-block" disabled>Sold out for these dates</button>';
    else if (!r.fits) cta = `<button class="btn btn-ghost btn-block" disabled>Sleeps ${r.capacity}${s.rooms > 1 ? ' per room' : ''}</button><span class="muted small">Add rooms to fit your group</span>`;
    else if (left < s.rooms) cta = `<button class="btn btn-ghost btn-block" disabled>Only ${left} room${left > 1 ? 's' : ''} left</button><span class="muted small">Reduce rooms to ${left}</span>`;
    else cta = `<a class="btn btn-accent btn-block" href="#/book?${bookQs(r)}">Reserve</a>`;
    return `<article class="room" data-room="${r.id}" data-avail="${r.available}">
      ${img(r.image || h.image, r.name)}
      <div><h3 style="margin-bottom:4px">${esc(r.name)}</h3>
        <p class="muted small" style="margin:0">🛏️ ${esc(r.beds)} · 📐 ${r.sizeSqm} m² · 👥 Sleeps ${r.capacity}</p>
        <div class="chips">${amenityChips(r.amenities, 5)}</div>${badge}</div>
      <div class="room-side"><div><span class="muted small">${money(r.pricePerNight)} / night</span><div class="price">${money(q.total)}</div>
        <span class="muted small">${plural(q.nights, 'night')} × ${plural(s.rooms, 'room')}, incl. taxes</span>
        ${q.discount ? `<br><span class="badge b-ok" style="margin-top:4px">You save ${money(q.discount)}</span>` : ''}</div>${cta}</div></article>`;
  };
  const paintRooms = (flashChanged = false, before = {}) => {
    $('#rooms-sub', root).textContent = `${fmtDate(s.checkIn, { day: 'numeric', month: 'short' })} to ${fmtDate(s.checkOut, { day: 'numeric', month: 'short' })} · ${plural(s.adults + s.children, 'guest')}`;
    $('#rooms', root).innerHTML = data.rooms.length ? data.rooms.map(roomHTML).join('')
      : '<div class="empty"><p class="muted">No rooms are listed for this hotel yet.</p></div>';
    if (flashChanged) $$('.room', root).forEach((el) => { if (before[el.dataset.room] != null && before[el.dataset.room] !== el.dataset.avail) el.classList.add('flash'); });
  };
  const paintReviews = () => {
    const total = data.hotel.reviewCount, bd = data.ratingBreakdown;
    $('#reviews', root).innerHTML = total ? `
      <div style="display:grid;grid-template-columns:150px 1fr;gap:20px;align-items:center;margin:8px 0 12px">
        <div class="center"><div class="price" style="font-size:2.6rem">${data.hotel.rating.toFixed(1)}</div><div class="stars">${'★'.repeat(Math.round(data.hotel.rating))}</div><span class="muted small">${plural(total, 'review')}</span></div>
        <div class="bars">${[5, 4, 3, 2, 1].map((n) => `<div class="bar"><span>${n}★</span><div class="track"><i style="width:${(bd[n] / total) * 100}%"></i></div><span>${bd[n]}</span></div>`).join('')}</div></div>
      ${data.reviews.map((r) => `<div class="review"><div style="display:flex;justify-content:space-between"><b>${esc(r.author)}</b><span class="stars">${'★'.repeat(r.rating)}</span></div>
        <p style="margin:4px 0 0">${esc(r.comment)}</p><span class="muted small">${fd(r.createdAt.slice(0, 10), { day: 'numeric', month: 'short', year: 'numeric' })}</span></div>`).join('')}`
      : '<p class="muted">No reviews yet. Guests can review after their stay.</p>';
  };
  paintRooms(); paintReviews();

  const unbind = bindSearchBox(root, s, async (v) => {
    s = setSearch(v);
    history.replaceState(null, '', `#/hotel/${id}?` + qs({ checkIn: s.checkIn, checkOut: s.checkOut, adults: s.adults, children: s.children, rooms: s.rooms }));
    $('#rooms', root).innerHTML = skeletonCards(2, 170);
    try { data = await fetchHotel(); paintRooms(); } catch (e) { toast(e.message, 'error'); }
  });

  // live updates: someone booked or cancelled → refresh the numbers and flash the rooms that changed
  const refresh = debounce(async () => {
    const before = Object.fromEntries($$('.room', root).map((el) => [el.dataset.room, el.dataset.avail]));
    try { data = await fetchHotel(); paintRooms(true, before); paintReviews(); } catch { /* keep old data */ }
  }, 300);
  const off = bus.on('availability', (e) => {
    if (String(e.hotelId) !== String(id)) return;
    refresh();
    if (e.reason === 'booked' || e.reason === 'cancelled') toast(e.reason === 'booked' ? 'A room here was just booked. Availability updated.' : 'A room here just became available.', 'info', 2800);
  });
  return () => { unbind(); off(); };
}
