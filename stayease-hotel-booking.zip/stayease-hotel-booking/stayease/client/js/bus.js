// Tiny publish/subscribe helper. The live-availability stream publishes here and pages subscribe.
const subs = {};
export const bus = {
  on(evt, fn) { (subs[evt] ||= new Set()).add(fn); return () => subs[evt].delete(fn); },
  emit(evt, data) { subs[evt]?.forEach((f) => f(data)); },
};
