// Small UI helpers shared by every page: escaping, formatting, toasts, modals, placeholders.
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
// Always escape anything that came from a user or the database before putting it in innerHTML.
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const money = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

export const todayISO = () => { const d = new Date(); return new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
export const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
export const diffDays = (a, b) => Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 864e5);
export const fmtDate = (s, o = { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }) =>
  new Date(s + 'T00:00:00Z').toLocaleDateString('en-IN', { ...o, timeZone: 'UTC' });
export const fmtDateTime = (s) => new Date(String(s).replace(' ', 'T') + 'Z').toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' });
export const plural = (n, w, p = w + 's') => `${n} ${n === 1 ? w : p}`;

export const AMENITY = {
  wifi: ['📶', 'Free WiFi'], pool: ['🏊', 'Swimming pool'], parking: ['🅿️', 'Free parking'], breakfast: ['🍳', 'Breakfast'],
  spa: ['💆', 'Spa'], gym: ['🏋️', 'Fitness centre'], restaurant: ['🍽️', 'Restaurant'], bar: ['🍸', 'Bar'],
  ac: ['❄️', 'Air conditioning'], pet: ['🐾', 'Pet friendly'], shuttle: ['🚐', 'Airport shuttle'], laundry: ['🧺', 'Laundry'],
};
export const amenityChips = (list, max = 5) => {
  const shown = list.slice(0, max).map((a) => `<span class="chip">${AMENITY[a]?.[0] || '•'} ${esc(AMENITY[a]?.[1] || a)}</span>`).join('');
  return shown + (list.length > max ? `<span class="chip">+${list.length - max} more</span>` : '');
};
export const stars = (n) => `<span class="stars" aria-label="${n} star hotel">${'★'.repeat(n)}${'☆'.repeat(5 - n)}</span>`;
export const ratingWord = (r) => (r >= 4.6 ? 'Exceptional' : r >= 4.2 ? 'Excellent' : r >= 3.8 ? 'Very good' : r >= 3.3 ? 'Good' : 'Fair');
export const ratingBadge = (r, n) => r
  ? `<div class="rating"><span><b>${ratingWord(r)}</b><br>${n} reviews</span><b>${r.toFixed(1)}</b></div>`
  : `<span class="muted small">No reviews yet</span>`;

// If a photo fails to load (offline, blocked, bad URL) we draw a tidy gradient with the hotel's initials instead.
window.__ph = (el) => {
  el.onerror = null;
  const t = (el.alt || '').replace(/[^A-Za-z0-9]/g, '').slice(0, 2).toUpperCase() || 'SE';
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='800' height='600'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#08434d'/><stop offset='1' stop-color='#f28f1c'/></linearGradient></defs><rect width='100%' height='100%' fill='url(#g)'/><text x='50%' y='54%' fill='white' fill-opacity='.9' font-size='110' font-family='Georgia,serif' text-anchor='middle'>${t}</text></svg>`;
  el.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
};
export const img = (src, alt, cls = '') => `<img class="${cls}" src="${esc(src)}" alt="${esc(alt)}" loading="lazy" onerror="__ph(this)">`;

export function toast(msg, type = 'info', ms = 3800) {
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.setAttribute('role', type === 'error' ? 'alert' : 'status');
  t.innerHTML = `<span>${{ success: '✅', error: '⚠️', info: 'ℹ️' }[type] || 'ℹ️'}</span><p>${esc(msg)}</p>`;
  $('#toasts').append(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, ms);
}

export function openModal(html, { wide = false } = {}) {
  closeModal();
  const root = $('#modal-root');
  root.innerHTML = `<div class="overlay"><div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">
    <button class="modal-x" aria-label="Close">×</button>${html}</div></div>`;
  const ov = root.firstElementChild;
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) closeModal(); });
  $('.modal-x', ov).onclick = closeModal;
  document.body.classList.add('noscroll');
  const first = $('input:not([type=checkbox]),select,textarea,button.btn', ov);
  first?.focus();
  return $('.modal', ov);
}
export function closeModal() { $('#modal-root').innerHTML = ''; document.body.classList.remove('noscroll'); }

export function confirmDialog({ title, message, confirmText = 'Confirm', cancelText = 'Keep it', danger = false }) {
  return new Promise((resolve) => {
    const m = openModal(`<h3>${esc(title)}</h3><p class="muted">${message}</p>
      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:18px">
        <button class="btn btn-ghost" data-no>${esc(cancelText)}</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-yes>${esc(confirmText)}</button></div>`);
    m.querySelector('[data-no]').onclick = () => { closeModal(); resolve(false); };
    m.querySelector('[data-yes]').onclick = () => { closeModal(); resolve(true); };
  });
}

// Disables a button and shows a spinner while an async action runs.
export async function busy(btn, fn) {
  if (btn.disabled) return;
  btn.disabled = true; btn.classList.add('loading');
  try { return await fn(); } finally { btn.disabled = false; btn.classList.remove('loading'); }
}

export const skeletonCards = (n = 4, h = 210) =>
  Array.from({ length: n }, () => `<div class="skel" style="height:${h}px"></div>`).join('');
export const errorState = (msg, retryLabel = 'Try again') => `<div class="empty fade-in"><div class="big">📡</div>
  <h3>Something went wrong</h3><p class="muted">${esc(msg)}</p><button class="btn btn-primary" data-retry>${retryLabel}</button></div>`;
export const emptyState = (icon, title, text, action = '') => `<div class="empty fade-in"><div class="big">${icon}</div>
  <h3>${esc(title)}</h3><p class="muted">${esc(text)}</p>${action}</div>`;

export function debounce(fn, ms = 350) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// Price breakdown rows shared by the booking page, confirmation page and booking details modal.
export function priceRows(p, { nights, rooms, pricePerNight } = {}) {
  const base = p.base ?? p.pricePerNight * p.nights * p.rooms;
  const label = nights ? `${money(pricePerNight)} × ${plural(nights, 'night')} × ${plural(rooms, 'room')}` : 'Room charges';
  return `<div class="sum-row"><span>${label}</span><span>${money(base)}</span></div>
    ${p.stayDiscount ? `<div class="sum-row"><span>Long-stay discount (${p.stayDiscountPct}%)</span><span class="neg">−${money(p.stayDiscount)}</span></div>` : ''}
    ${p.couponDiscount ? `<div class="sum-row"><span>Coupon ${esc(p.coupon)}</span><span class="neg">−${money(p.couponDiscount)}</span></div>` : ''}
    <div class="sum-row"><span>Taxes (GST ${p.taxRate}%)</span><span>${money(p.tax)}</span></div>
    <div class="sum-row total"><span>Total</span><span>${money(p.total)}</span></div>`;
}
