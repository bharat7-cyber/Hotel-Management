// Login / register dialog, shared by the nav bar and any page that needs a signed-in user.
import { api } from './api.js';
import { $, $$, esc, toast, openModal, closeModal, busy } from './ui.js';
import { setSession } from './session.js';
import { bus } from './bus.js';

// Login / register dialog. Returns a promise that resolves to true when the user signs in.
export function showAuth(tab = 'login', message = '') {
  return new Promise((resolve) => {
    const m = openModal(`
      <div class="tabs" style="margin-top:0"><button class="tab ${tab === 'login' ? 'on' : ''}" data-t="login">Log in</button><button class="tab ${tab === 'register' ? 'on' : ''}" data-t="register">Create account</button></div>
      ${message ? `<div class="notice n-info">${esc(message)}</div>` : ''}
      <form id="auth-form" novalidate>
        <div class="field" id="f-name" ${tab === 'login' ? 'hidden' : ''}><label for="a-name">Full name</label><input id="a-name" autocomplete="name"></div>
        <div class="field"><label for="a-email">Email</label><input id="a-email" type="email" autocomplete="email"></div>
        <div class="field"><label for="a-pw">Password</label><input id="a-pw" type="password" autocomplete="${tab === 'login' ? 'current-password' : 'new-password'}" placeholder="At least 6 characters"></div>
        <div class="notice n-bad" id="a-err" hidden></div>
        <button class="btn btn-primary btn-block" type="submit">${tab === 'login' ? 'Log in' : 'Create account'}</button>
      </form>
      <p class="muted small center" style="margin-top:14px">Try the demo: <a href="#" data-fill="demo">guest account</a> · <a href="#" data-fill="admin">admin account</a></p>`);
    let mode = tab, done = false;
    const setMode = (t) => {
      mode = t;
      $$('.tab', m).forEach((b) => b.classList.toggle('on', b.dataset.t === t));
      $('#f-name', m).hidden = t === 'login';
      $('#auth-form button[type=submit]', m).textContent = t === 'login' ? 'Log in' : 'Create account';
    };
    $$('.tab', m).forEach((b) => (b.onclick = () => setMode(b.dataset.t)));
    $$('[data-fill]', m).forEach((a) => (a.onclick = (e) => {
      e.preventDefault(); setMode('login');
      $('#a-email', m).value = a.dataset.fill === 'admin' ? 'admin@stayease.com' : 'demo@stayease.com';
      $('#a-pw', m).value = a.dataset.fill === 'admin' ? 'admin123' : 'demo123';
    }));
    $('#auth-form', m).addEventListener('submit', async (e) => {
      e.preventDefault();
      const err = $('#a-err', m); err.hidden = true;
      const body = { email: $('#a-email', m).value.trim(), password: $('#a-pw', m).value };
      if (mode === 'register') body.name = $('#a-name', m).value.trim();
      await busy($('button[type=submit]', m), async () => {
        try {
          const data = await api(mode === 'login' ? '/auth/login' : '/auth/register', { method: 'POST', body });
          setSession(data); done = true; closeModal();
          toast(mode === 'login' ? `Welcome back, ${data.user.name.split(' ')[0]}!` : 'Account created. Welcome to StayEase!', 'success');
          resolve(true);
          bus.emit('login');
        } catch (ex) { err.textContent = ex.message; err.hidden = false; }
      });
    });
    new MutationObserver((_, obs) => { if (!$('#auth-form')) { obs.disconnect(); if (!done) resolve(false); } })
      .observe($('#modal-root'), { childList: true });
  });
}

